-- ============================================================
-- 001_init.sql — Esquema inicial con UUID autogenerados
-- ============================================================

-- Activar extensión para generar UUID
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ------------------------------------------------------------
-- Tabla de usuarios registrados en el sistema
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id           UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    display_name TEXT        NOT NULL DEFAULT '',
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ------------------------------------------------------------
-- Salas de chat
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS rooms (
    id           UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    name         TEXT        NOT NULL,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Membresía: qué usuarios pertenecen a qué sala
CREATE TABLE IF NOT EXISTS room_members (
    room_id      UUID        NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
    user_id      UUID        NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    joined_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (room_id, user_id)
);

-- ------------------------------------------------------------
-- Mensajes de chat
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS messages (
    id           UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    room_id      UUID        NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
    sender_id    UUID        NOT NULL,             -- puede ser sistema, no FK obligatoria
    content      TEXT        NOT NULL,
    sent_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ------------------------------------------------------------
-- Notificaciones y alertas de correo pendientes
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pending_events (
    id           UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id      UUID        NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    event_type   TEXT        NOT NULL,             -- 'notify' | 'mail_update'
    payload      JSONB       NOT NULL,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_pending_events_user
    ON pending_events (user_id, created_at);

-- ------------------------------------------------------------
-- Mensajes no entregados a destinatarios offline
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS undelivered_messages (
    id           UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    message_id   UUID        NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
    user_id      UUID        NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (message_id, user_id)
);

CREATE INDEX IF NOT EXISTS idx_undelivered_user
    ON undelivered_messages (user_id, created_at);
