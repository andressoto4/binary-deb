//! Asistente interactivo de configuración inicial para ws-unp.
//!
//! Este módulo implementa el subcomando `setup` de `ws-unp`. Se invoca con:
//! ```bash
//! sudo ws-unp setup
//! ```
//!
//! La herramienta guía al administrador a través de los siguientes pasos:
//! 1. Solicita interactivamente los parámetros de configuración:
//!    - Puerto WebSocket
//!    - Host y puerto de PostgreSQL
//!    - Nombre de la base de datos
//!    - Usuario y contraseña (si no se ingresa, se genera automáticamente)
//! 2. Muestra un resumen de la configuración y pide confirmación.
//! 3. Crea el usuario y la base de datos en PostgreSQL si el servidor es local.
//! 4. Escribe el archivo de configuración `/etc/ws-unp/ws-unp.conf` con permisos seguros (640 root:ws-unp).
//! 5. Ejecuta las migraciones SQL (CREATE TABLE IF NOT EXISTS) si se confirma.
//! 6. Habilita e inicia el servicio systemd `ws-unp` si se confirma.
//!
//! # Parámetros de configuración relevantes
//! - `ws_port`: Puerto TCP donde escuchará el servidor WebSocket (por defecto 1520).
//! - `pg_host`: Dirección del servidor PostgreSQL (localhost/127.0.0.1/::1 activan creación local).
//! - `pg_port`: Puerto de PostgreSQL (por defecto 5432).
//! - `db_name`: Nombre de la base de datos (por defecto `sgdea`).
//! - `db_user`: Usuario de PostgreSQL que poseerá la base de datos (por defecto `ws_unp`).
//! - `db_pass`: Contraseña para el usuario; se genera automáticamente si se deja vacío.
//!
//! # Seguridad
//! - El archivo de configuración se escribe con permisos 640 (root:ws-unp) para que solo el servicio y root puedan leerlo.
//! - Las contraseñas no se muestran en el resumen ni se registran en logs.
//! - La creación de usuario en PostgreSQL se realiza con `psql` a través del usuario `postgres` (autenticación peer), evitando exponer credenciales en la línea de comandos.
//! - La contraseña generada utiliza `openssl rand -base64` si está disponible, o un UUID v4 como fallback.
//!
//! # Panics
//! Ninguna función de este módulo entra en pánico de forma deliberada; los errores se manejan
//! mostrando mensajes al usuario y, en casos críticos, se termina el proceso con `std::process::exit(1)`.

use std::io::{self, BufRead, Write};

use rpassword::prompt_password;
use uuid::Uuid;

const CONF_DIR:  &str = "/etc/ws-unp";
const CONF_PATH: &str = "/etc/ws-unp/ws-unp.conf";

// ── Punto de entrada

/// Ejecuta el asistente de configuración interactivo.
///
/// Es la función principal que orquesta todo el proceso:
/// 1. Verifica que se tengan permisos de escritura (aborta si no).
/// 2. Muestra el banner inicial.
/// 3. Recopila los parámetros de configuración desde el usuario.
/// 4. Muestra un resumen y pide confirmación.
/// 5. Crea el usuario y base de datos en PostgreSQL (solo si el host es local).
/// 6. Escribe el archivo de configuración en `/etc/ws-unp/ws-unp.conf`.
/// 7. Ejecuta las migraciones SQL si el usuario lo aprueba.
/// 8. Habilita e inicia el servicio systemd si el usuario lo aprueba.
/// 9. Muestra el mensaje final con instrucciones.
///
/// # Comportamiento
/// - Si el usuario cancela en el resumen, el programa termina sin hacer cambios.
/// - Si ocurre un error crítico (por ejemplo, no se puede escribir el archivo de configuración),
///   se imprime un mensaje y se sale con código de error 1.
/// - Las funciones auxiliares manejan sus propios errores y muestran mensajes informativos.
///
/// # Seguridad
/// - La contraseña nunca se muestra en claro en la terminal ni se guarda en logs.
/// - El archivo de configuración se crea con permisos restrictivos.
pub fn run_setup() {
    ensure_write_access();

    banner();

    // ── Paso 1: recopilar parámetros
    let ws_port = prompt_validated(
        "Puerto WebSocket",
        "1520",
        |v| v.parse::<u16>().map(|_| ()).map_err(|_| "Debe ser un número entre 1 y 65535".into()),
    );

    let pg_host = prompt("Host de PostgreSQL", "localhost");
    let pg_port = prompt_validated(
        "Puerto de PostgreSQL",
        "5432",
        |v| v.parse::<u16>().map(|_| ()).map_err(|_| "Debe ser un número entre 1 y 65535".into()),
    );
    let db_name = prompt_identifier("Nombre de la base de datos", "sgdea");
    let db_user = prompt_identifier("Usuario de PostgreSQL para ws-unp", "ws_unp");

    let db_pass = match prompt_password(
        format!("  Contraseña para '{}' [Enter = generar automáticamente]: ", db_user)
    ) {
        Ok(p) if p.trim().is_empty() => {
            let generated = generate_password();
            println!("  Contraseña generada automáticamente.");
            generated
        }
        Ok(p) => p.trim().to_string(),
        Err(_) => generate_password(),
    };

    let database_url = format!(
        "postgres://{}:{}@{}:{}/{}",
        db_user, db_pass, pg_host, pg_port, db_name
    );

    // ── Paso 2: mostrar resumen y confirmar
    show_summary(&ws_port, &pg_host, &pg_port, &db_name, &db_user);

    if prompt("¿Continuar con esta configuración?", "S").eq_ignore_ascii_case("n") {
        println!("Cancelado. No se realizaron cambios.");
        std::process::exit(0);
    }

    // ── Paso 3: crear usuario y BD en PostgreSQL (si es local)
    let is_local = matches!(pg_host.as_str(), "localhost" | "127.0.0.1" | "::1");
    print_step(1, 4, "PostgreSQL");
    if is_local {
        println!(" (configurando localmente)...");
        setup_postgres(&db_user, &db_pass, &db_name);
    } else {
        println!(" (remoto — omitiendo creación local).");
        println!("      Asegúrese de que el usuario '{}' y la base '{}' existan en {}.",
                 db_user, db_name, pg_host);
    }

    // ── Paso 4: escribir /etc/ws-unp/ws-unp.conf
    print_step(2, 4, &format!("Escribiendo {}", CONF_PATH));
    write_conf(&ws_port, &database_url);
    println!("      Configuración guardada (permisos 640 root:ws-unp).");

    // ── Paso 5: migraciones SQL
    print_step(3, 4, "Migraciones SQL");
    if !prompt("¿Crear las tablas ahora (CREATE TABLE IF NOT EXISTS)?", "S")
        .eq_ignore_ascii_case("n")
    {
        run_migrations(&database_url);
    } else {
        println!("      Omitido. Ejecute más tarde:");
        println!("        sudo -u ws-unp ws-unp --migrate");
    }

    // ── Paso 6: habilitar e iniciar systemd
    print_step(4, 4, "Servicio systemd");
    if !prompt("¿Habilitar e iniciar ws-unp ahora?", "S").eq_ignore_ascii_case("n") {
        enable_service();
    } else {
        println!("      Para iniciarlo más tarde:");
        println!("        systemctl enable --now ws-unp");
    }

    // ── Fin
    show_final_message();
}

// ── Helpers de entrada

/// Imprime el banner inicial con el nombre del asistente y la UNP.
///
/// El banner es un recuadro de asteriscos que presenta la herramienta y las instrucciones básicas.
fn banner() {
    print_box(&[
        "ws-unp — Asistente de configuración inicial",
        "Unidad Nacional de Protección (UNP)",
        "",
        "Responda cada pregunta o pulse Enter para aceptar",
        "el valor por defecto que aparece entre corchetes.",
    ]);
}

/// Imprime un recuadro con asteriscos alrededor de las líneas de texto.
///
/// # Parámetros
/// - `lines`: vector de cadenas, cada una será una línea del recuadro.
///            Las líneas vacías se imprimen como líneas en blanco con asteriscos en los bordes.
///
/// # Algoritmo
/// 1. Calcula el ancho máximo de línea (sin contar márgenes) y añade 4 espacios para los bordes.
/// 2. Genera una línea superior e inferior con `"*"` repetido el ancho total.
/// 3. Para cada línea, la centra dentro del ancho total y la rodea con `"* "` y `" *"`.
///
/// # Ejemplo
/// ```
/// print_box(&["Hola", "Mundo"]);
/// ```
/// Imprime:
/// ```text
/// **********
/// *  Hola  *
/// *  Mundo *
/// **********
/// ```
fn print_box(lines: &[&str]) {
    let width = lines.iter()
        .map(|line| line.chars().count())
        .max()
        .unwrap_or(0) + 4; // +4 para "| " y " |" con un espacio de margen

    let sep = "*".repeat(width);
    println!("\n{sep}");
    for line in lines {
        let padding = width - line.chars().count() - 4;
        let left_pad = padding / 2;
        let right_pad = padding - left_pad;
        println!(
            "* {}{}{} *",
            " ".repeat(left_pad),
            line,
            " ".repeat(right_pad)
        );
    }
    println!("{sep}\n");
}

/// Lee una línea de stdin; devuelve el valor por defecto si el usuario no escribe nada.
///
/// # Parámetros
/// - `question`: Texto de la pregunta que se muestra al usuario.
/// - `default`: Valor que se usará si la entrada está vacía.
///
/// # Retorno
/// Una cadena con la respuesta del usuario (trimmed) o el valor por defecto.
///
/// # Panics
/// Puede entrar en pánico si falla la lectura de stdin o el flush de stdout,
/// pero en un entorno interactivo normal esto no debería ocurrir.
///
/// # Ejemplo
/// ```
/// let respuesta = prompt("Nombre", "anonimo");
/// ```
fn prompt(question: &str, default: &str) -> String {
    print!("  {question} [{}]: ", default);
    io::stdout().flush().unwrap();
    let stdin = io::stdin();
    let mut line = String::new();
    stdin.lock().read_line(&mut line).unwrap();
    let trimmed = line.trim().to_string();
    if trimmed.is_empty() { default.to_string() } else { trimmed }
}

/// Como `prompt`, pero re-intenta si el validador devuelve error.
///
/// # Parámetros
/// - `question`: Igual que en `prompt`.
/// - `default`: Valor por defecto.
/// - `validate`: Función que recibe la entrada y devuelve `Ok(())` si es válida, o `Err(String)` con un mensaje de error.
///
/// # Retorno
/// La primera entrada que pase la validación.
///
/// # Comportamiento
/// - Si la validación falla, se muestra el mensaje de error y se vuelve a preguntar.
/// - El valor por defecto se usa solo si la entrada está vacía, pero también se valida.
///
/// # Seguridad
/// La validación se ejecuta en el hilo actual; no se evalúa código externo.
fn prompt_validated(
    question: &str,
    default: &str,
    validate: impl Fn(&str) -> Result<(), String>,
) -> String {
    loop {
        let value = prompt(question, default);
        match validate(&value) {
            Ok(_) => return value,
            Err(msg) => println!("  Error: {msg}. Inténtelo de nuevo."),
        }
    }
}

/// Solicita un identificador PostgreSQL válido (letras, dígitos, guión_bajo).
///
/// # Restricciones
/// - Solo caracteres alfanuméricos y guión bajo (`_`).
/// - No puede comenzar con un dígito.
///
/// # Parámetros
/// - `question`: Texto de la pregunta.
/// - `default`: Valor por defecto.
///
/// # Retorno
/// Un identificador que cumple las reglas.
///
/// # Seguridad
/// Previene inyección SQL indirecta al restringir los caracteres permitidos.
fn prompt_identifier(question: &str, default: &str) -> String {
    prompt_validated(question, default, |v| {
        if v.chars().all(|c| c.is_alphanumeric() || c == '_') && !v.starts_with(|c: char| c.is_ascii_digit()) {
            Ok(())
        } else {
            Err("Solo letras, números y _ (no puede comenzar con dígito)".into())
        }
    })
}

// ── Generación de contraseña

/// Genera una contraseña segura usando `openssl rand -base64` si está disponible,
/// o un UUID v4 sin guiones como fallback.
///
/// # Algoritmo
/// 1. Intenta ejecutar `openssl rand -base64 32` y extraer los caracteres alfanuméricos.
/// 2. Si tiene al menos 16 caracteres, los toma como contraseña.
/// 3. En caso contrario, genera un UUID v4 y elimina los guiones.
///
/// # Retorno
/// Una cadena de entre 16 y 32 caracteres alfanuméricos.
///
/// # Seguridad
/// - `openssl rand -base64` proporciona 32 bytes de entropía (256 bits) en base64.
/// - El filtrado de caracteres no alfanuméricos reduce un poco la entropía, pero sigue siendo muy segura.
/// - El fallback UUID v4 tiene 128 bits de entropía.
fn generate_password() -> String {
    if let Ok(out) = std::process::Command::new("openssl")
        .args(["rand", "-base64", "32"])
        .output()
    {
        if out.status.success() {
            let pw: String = String::from_utf8_lossy(&out.stdout)
                .chars()
                .filter(|c| c.is_alphanumeric())
                .take(32)
                .collect();
            if pw.len() >= 16 { return pw; }
        }
    }
    Uuid::new_v4().to_string().replace('-', "")
}

// ── PostgreSQL

/// Crea o actualiza el usuario y la base de datos en PostgreSQL (solo en local).
///
/// # Parámetros
/// - `db_user`: Nombre del usuario de PostgreSQL.
/// - `db_pass`: Contraseña para ese usuario.
/// - `db_name`: Nombre de la base de datos.
///
/// # Comportamiento
/// 1. Verifica si PostgreSQL está accesible con `pg_isready`. Si no, muestra instrucciones manuales.
/// 2. Escapa la contraseña para SQL (reemplaza `'` por `''`).
/// 3. Crea o actualiza el usuario con un bloque `DO $$ ... $$`.
/// 4. Crea la base de datos si no existe, asignándole el usuario como propietario.
///
/// # Seguridad
/// - La contraseña se escapa correctamente para evitar inyección SQL.
/// - Se usa `su postgres -c psql` con entrada por stdin para no exponer la contraseña en la línea de comandos.
/// - Los errores de `psql` se muestran al usuario a través de `stderr`.
///
/// # Nota
/// Esta función solo se invoca cuando `pg_host` es `localhost`, `127.0.0.1` o `::1`.
fn setup_postgres(db_user: &str, db_pass: &str, db_name: &str) {
    let ready = std::process::Command::new("pg_isready")
        .output()
        .map(|o| o.status.success())
        .unwrap_or(false);

    if !ready {
        println!("      PostgreSQL no accesible. Cree manualmente:");
        println!("      CREATE USER {db_user} WITH PASSWORD '***';");
        println!("      CREATE DATABASE {db_name} OWNER {db_user};");
        return;
    }

    let safe_pass = db_pass.replace('\'', "''");

    let user_sql = format!(
        "DO $$ BEGIN \
           IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = '{db_user}') THEN \
             CREATE USER {db_user} WITH PASSWORD '{safe_pass}'; \
           ELSE \
             ALTER USER {db_user} WITH PASSWORD '{safe_pass}'; \
           END IF; \
         END $$;"
    );
    if pg_exec_stdin(&user_sql) {
        println!("      Usuario '{db_user}' configurado.");
    } else {
        println!("      No se pudo crear el usuario '{db_user}'.");
        println!("      Verifique que el usuario del sistema 'postgres' existe.");
    }

    let db_exists: i32 = pg_query_stdin(
        &format!("SELECT COUNT(*) FROM pg_database WHERE datname = '{db_name}'")
    );
    if db_exists == 0 {
        if pg_exec_stdin(&format!("CREATE DATABASE {db_name} OWNER {db_user}")) {
            println!("      Base de datos '{db_name}' creada.");
        } else {
            println!("      No se pudo crear la base '{db_name}'.");
        }
    } else {
        println!("      Base de datos '{db_name}' ya existe.");
    }
}

/// Ejecuta SQL en PostgreSQL usando peer auth del usuario 'postgres' via su.
/// El SQL se envía por stdin para evitar problemas de escapado en la shell.
///
/// # Parámetros
/// - `sql`: Comando SQL a ejecutar.
///
/// # Retorno
/// `true` si el comando se ejecutó con éxito, `false` en caso contrario.
///
/// # Seguridad
/// - No se expone la contraseña en la línea de comandos.
/// - El comando se ejecuta como el usuario `postgres` a través de `su`, aprovechando la autenticación peer.
/// - La entrada se escribe directamente en el stdin de `psql`, evitando la interpolación de la shell.
///
/// # Detalles de implementación
/// Se utiliza `psql -q` para modo silencioso (sin mensajes de bienvenida).
/// Los errores se envían a stderr, que se hereda para que el usuario los vea.
fn pg_exec_stdin(sql: &str) -> bool {
    use std::io::Write as _;
    use std::process::{Command, Stdio};

    let mut child = match Command::new("su")
        .args(["-s", "/bin/sh", "postgres", "-c", "psql -q"])
        .stdin(Stdio::piped())
        .stdout(Stdio::null())
        .stderr(Stdio::inherit())
        .spawn()
    {
        Ok(c) => c,
        Err(_) => return false,
    };

    if let Some(mut stdin) = child.stdin.take() {
        let _ = stdin.write_all(sql.as_bytes());
    }

    child.wait().map(|s| s.success()).unwrap_or(false)
}

/// Ejecuta una consulta SQL y devuelve el primer valor entero del resultado.
///
/// # Parámetros
/// - `sql`: Consulta SQL que debe devolver una sola fila con un entero.
///
/// # Retorno
/// El entero devuelto por la consulta, o `0` si ocurre algún error.
///
/// # Seguridad
/// Similar a `pg_exec_stdin`, pero se captura la salida estándar.
/// Se usa `psql -tA` para obtener solo los valores (sin encabezados, sin alineación).
///
/// # Nota
/// Esta función no maneja valores no numéricos; si la consulta no devuelve un entero,
/// se devuelve `0`.
fn pg_query_stdin(sql: &str) -> i32 {
    use std::io::Write as _;
    use std::process::{Command, Stdio};

    let mut child = match Command::new("su")
        .args(["-s", "/bin/sh", "postgres", "-c", "psql -tA"])
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::null())
        .spawn()
    {
        Ok(c) => c,
        Err(_) => return 0,
    };

    if let Some(mut stdin) = child.stdin.take() {
        let _ = stdin.write_all(sql.as_bytes());
    }

    child.wait_with_output()
        .map(|o| String::from_utf8_lossy(&o.stdout).trim().parse().unwrap_or(0))
        .unwrap_or(0)
}

// ── Archivo de configuración

/// Escribe el archivo de configuración en `/etc/ws-unp/ws-unp.conf` con permisos 640.
///
/// # Parámetros
/// - `ws_port`: Puerto WebSocket.
/// - `database_url`: URL de conexión a PostgreSQL.
///
/// # Comportamiento
/// 1. Si el directorio `/etc/ws-unp` no existe, lo crea con permisos 750 y propietario `root:ws-unp`.
/// 2. Genera el contenido del archivo con comentarios explicativos.
/// 3. Escribe el archivo y luego ajusta permisos a 640 y propietario `root:ws-unp`.
///
/// # Seguridad
/// - Los permisos restrictivos (640) aseguran que solo root y el grupo `ws-unp` puedan leer el archivo.
/// - El archivo contiene la contraseña en texto plano, pero con estos permisos está protegido.
///
/// # Panics
/// Si no se puede escribir el archivo, se imprime un error y se termina el proceso con código 1.
fn write_conf(ws_port: &str, database_url: &str) {
    if !std::path::Path::new(CONF_DIR).exists() {
        if let Err(e) = std::fs::create_dir_all(CONF_DIR) {
            eprintln!("Error: no se pudo crear {CONF_DIR}: {e}");
            std::process::exit(1);
        }
        std::process::Command::new("chmod").args(["750", CONF_DIR]).status().ok();
        std::process::Command::new("chown").args(["root:ws-unp", CONF_DIR]).status().ok();
    }

    let content = format!(
        "# /etc/ws-unp/ws-unp.conf\n\
         # Generado por: sudo ws-unp setup\n\
         # Recargue sin reiniciar: systemctl reload ws-unp\n\
         # Aplicar cambios:        systemctl restart ws-unp\n\
         \n\
         ws_port={ws_port}\n\
         database_url={database_url}\n\
         \n\
         # TLS/WSS (opcional — descomente para habilitar WSS):\n\
         #TLS_CERT_PATH=/etc/ws-unp/cert.pem\n\
         #TLS_KEY_PATH=/etc/ws-unp/key.pem\n"
    );

    if let Err(e) = std::fs::write(CONF_PATH, &content) {
        eprintln!("Error al escribir {CONF_PATH}: {e}");
        std::process::exit(1);
    }

    std::process::Command::new("chown").args(["root:ws-unp", CONF_PATH]).status().ok();
    std::process::Command::new("chmod").args(["640", CONF_PATH]).status().ok();
}

// ── Migraciones SQL

/// Ejecuta el archivo SQL de migraciones (`ws.sql`) contra la base de datos.
///
/// # Parámetros
/// - `database_url`: URL de conexión a PostgreSQL.
///
/// # Comportamiento
/// 1. Busca el archivo `ws.sql` en `/usr/share/ws-unp/` (instalación .deb) o en `db/ws.sql` (ejecución desde fuente).
/// 2. Si no lo encuentra, muestra instrucciones para ejecutar manualmente.
/// 3. Ejecuta `psql $database_url -f $sql_path -q`.
/// 4. Muestra el resultado de la operación.
///
/// # Seguridad
/// La URL de conexión contiene la contraseña, pero se pasa como argumento a `psql`.
/// Dado que el comando se ejecuta en el mismo proceso, otros usuarios no podrían verla fácilmente.
/// No obstante, se podría mejorar usando variables de entorno, pero por simplicidad se usa así.
fn run_migrations(database_url: &str) {
    let sql_path = if std::path::Path::new("/usr/share/ws-unp/ws.sql").exists() {
        "/usr/share/ws-unp/ws.sql"
    } else if std::path::Path::new("db/ws.sql").exists() {
        "db/ws.sql"
    } else {
        println!("      No se encontró el archivo SQL.");
        println!("      Ejecute luego: sudo -u ws-unp ws-unp --migrate");
        return;
    };

    let status = std::process::Command::new("psql")
        .args([database_url, "-f", sql_path, "-q"])
        .status();

    match status {
        Ok(s) if s.success() => println!("      Tablas creadas desde '{sql_path}'."),
        _ => {
            println!("      Error al ejecutar migraciones.");
            println!("      Ejecute luego: sudo -u ws-unp ws-unp --migrate");
        }
    }
}

// ── Servicio systemd

/// Habilita e inicia el servicio systemd `ws-unp`.
///
/// # Comportamiento
/// Ejecuta `systemctl enable ws-unp` y `systemctl start ws-unp`.
/// Muestra mensajes de éxito o error según el resultado.
///
/// # Seguridad
/// Esta función debe ejecutarse con privilegios de superusuario (como parte de `sudo ws-unp setup`).
fn enable_service() {
    let enabled = std::process::Command::new("systemctl")
        .args(["enable", "ws-unp"])
        .status()
        .map(|s| s.success())
        .unwrap_or(false);

    let started = std::process::Command::new("systemctl")
        .args(["start", "ws-unp"])
        .status()
        .map(|s| s.success())
        .unwrap_or(false);

    if enabled && started {
        println!("      Servicio ws-unp habilitado e iniciado.");
    } else {
        println!("      No se pudo iniciar el servicio automáticamente.");
        println!("        Ejecute: systemctl enable --now ws-unp");
    }
}

// ── Permisos de escritura

/// Verifica que se pueda escribir en el directorio de configuración o en el directorio actual.
/// Si falla, aborta con un mensaje indicando que debe ejecutarse con `sudo`.
///
/// # Comportamiento
/// Intenta escribir un archivo temporal en `/etc/ws-unp/` (si existe) o en el directorio actual.
/// Si tiene éxito, lo borra; si falla, asume que no hay permisos y termina el proceso.
///
/// # Panics
/// No entra en pánico; termina el proceso con `std::process::exit(1)` si no hay permisos.
fn ensure_write_access() {
    let test_target = if std::path::Path::new(CONF_DIR).exists() {
        format!("{CONF_DIR}/.ws-unp-setup-check")
    } else {
        ".ws-unp-setup-check".to_string()
    };

    match std::fs::write(&test_target, "") {
        Ok(_) => {
            let _ = std::fs::remove_file(&test_target);
        }
        Err(_) => {
            eprintln!("Error: sin permisos de escritura.");
            eprintln!("Ejecute con sudo:\n  sudo ws-unp setup");
            std::process::exit(1);
        }
    }
}

// ── Estilo visual

/// Muestra el resumen de la configuración en un recuadro con asteriscos.
///
/// # Parámetros
/// - `ws_port`: Puerto WebSocket.
/// - `pg_host`: Host de PostgreSQL.
/// - `pg_port`: Puerto de PostgreSQL.
/// - `db_name`: Nombre de la base de datos.
/// - `db_user`: Usuario de PostgreSQL.
/// - `database_url`: URL de conexión (se muestra con la contraseña oculta).
///
/// # Seguridad
/// La contraseña se reemplaza por `***` en la salida.
fn show_summary(
    ws_port: &str,
    pg_host: &str,
    pg_port: &str,
    db_name: &str,
    db_user: &str,
) {
    let line_port  = format!("Puerto WebSocket  : {}", ws_port);
    let line_pg    = format!("PostgreSQL        : {}:{}", pg_host, pg_port);
    let line_db    = format!("Base de datos     : {}", db_name);
    let line_user  = format!("Usuario BD        : {}", db_user);
    let line_url   = format!("database_url      : postgres://{}:***@{}:{}/{}", db_user, pg_host, pg_port, db_name);

    let lines = vec![
        "Resumen de configuración",
        "",
        line_port.as_str(),
        line_pg.as_str(),
        line_db.as_str(),
        line_user.as_str(),
        "",
        line_url.as_str(),
    ];
    print_box(&lines);
}

/// Imprime un paso numerado en el estilo "[n/m] Título".
///
/// # Parámetros
/// - `current`: Número del paso actual (1-indexado).
/// - `total`: Total de pasos.
/// - `title`: Título del paso.
fn print_step(current: usize, total: usize, title: &str) {
    println!("\n[{}/{}] {}", current, total, title);
}

/// Muestra el mensaje final con instrucciones de post-configuración.
///
/// El mensaje se imprime dentro de un recuadro de asteriscos.
fn show_final_message() {
    let lines = vec![
        "Configuración completada correctamente.",
        "",
        "Logs en tiempo real : journalctl -u ws-unp -f",
        "Estado del servicio : systemctl status ws-unp",
        "Archivo de config   : /etc/ws-unp/ws-unp.conf",
    ];
    print_box(&lines);
}