//! Modelos de base de datos para ws-unp.
//!
//! Este módulo define las estructuras que representan tablas en PostgreSQL.
//! Utilizan `serde` para serialización/deserialización y `sqlx::FromRow`
//! para mapeo automático desde filas de consultas SQL.
//!
//! # Modelos
//! - `PendingEvent`: Eventos pendientes para usuarios que no están conectados.
//! - `UndeliveredMessage`: Mensajes de sala que aún no han sido entregados.

use serde::{Deserialize, Serialize};
use time::OffsetDateTime;
use uuid::Uuid;

/// Representa un evento pendiente para un usuario.
///
/// Esta tabla almacena eventos que deben ser entregados a usuarios cuando se conecten.
/// Puede incluir notificaciones, alertas de correo, etc. El campo `payload` contiene
/// el evento en formato JSON, listo para enviarse directamente al cliente.
///
/// # Campos
/// - `id`: Identificador único del evento.
/// - `user_id`: Usuario destinatario (relación con la tabla de usuarios).
/// - `event_type`: Tipo de evento (ej: "notify", "mail_update").
/// - `payload`: Datos del evento en formato JSON, serializados como JSONB en la BD.
/// - `created_at`: Marca de tiempo de creación.
#[derive(Debug, Serialize, Deserialize, sqlx::FromRow)]
pub struct PendingEvent {
    pub id: Uuid,
    pub user_id: Uuid,
    pub event_type: String,
    /// JSON almacenado como texto en la fila (campo payload JSONB)
    pub payload: serde_json::Value,
    pub created_at: OffsetDateTime,
}

/// Representa un mensaje de sala que no ha sido entregado a algún destinatario.
///
/// Se usa para almacenar mensajes históricos o cuando un cliente se desconecta
/// antes de recibirlos. El sistema puede reenviarlos al reconectar.
///
/// # Campos
/// - `id`: Identificador único del registro de mensaje no entregado.
/// - `message_id`: Identificador del mensaje original (puede referenciar una tabla de mensajes).
/// - `room_id`: Sala a la que pertenece el mensaje.
/// - `sender_id`: Usuario que envió el mensaje.
/// - `content`: Contenido del mensaje (texto).
/// - `sent_at`: Marca de tiempo de cuando se envió originalmente.
#[derive(Debug, Serialize, Deserialize, sqlx::FromRow)]
pub struct UndeliveredMessage {
    pub id: Uuid,
    pub message_id: Uuid,
    pub room_id: Uuid,
    pub sender_id: Uuid,
    pub content: String,
    pub sent_at: OffsetDateTime,
}