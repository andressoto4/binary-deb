//! Módulo de acceso a la base de datos PostgreSQL para ws-unp.
//!
//! Este módulo proporciona funcionalidades para crear un pool de conexiones
//! eficiente y ejecutar migraciones del esquema SQL. Está diseñado para ser
//! utilizado tanto en el servidor principal como en el asistente de configuración.
//!
//! # Características
//! - Pool de conexiones con 30 conexiones máximas (suficiente para ~2000 usuarios concurrentes).
//! - Migraciones idempotentes (usando `IF NOT EXISTS`) que pueden ejecutarse múltiples veces.
//! - Búsqueda flexible del archivo SQL según el entorno (producción o desarrollo).
//!
//! # Seguridad
//! - Las migraciones se ejecutan con las credenciales de la URL de conexión.
//! - El pool limita el número de conexiones para evitar saturar la base de datos.

pub mod models;
pub mod queries;

use sqlx::postgres::PgPoolOptions;
use sqlx::PgPool;

/// Crea el pool de conexiones a PostgreSQL.
///
/// # Parámetros
/// - `database_url`: Cadena de conexión en formato PostgreSQL (ej: `postgres://usuario:clave@host:puerto/db`).
///
/// # Retorno
/// `Result<PgPool, sqlx::Error>` – pool de conexiones listo para usar, o un error si falla la conexión.
///
/// # Comportamiento
/// Configura un máximo de 30 conexiones simultáneas. Este número soporta holgadamente
/// 2000 usuarios concurrentes porque el broadcast de mensajes ya ocurre en memoria
/// antes de tocar la base de datos. Las operaciones de lectura/escritura son mínimas.
///
/// # Seguridad
/// La URL de conexión contiene la contraseña en texto plano, pero se pasa directamente
/// a `sqlx`, que la maneja de forma segura (no se expone en logs a menos que se registre explícitamente).
pub async fn create_pool(database_url: &str) -> Result<PgPool, sqlx::Error> {
    PgPoolOptions::new()
        .max_connections(30)
        .connect(database_url)
        .await
}

/// Ejecuta el archivo SQL de esquema contra la base de datos.
///
/// El script SQL debe ser idempotente (usar `IF NOT EXISTS` en todas las sentencias),
/// permitiendo ejecutarlo múltiples veces sin errores. Esto es útil para actualizaciones
/// y para el primer despliegue.
///
/// # Resolución de la ruta del archivo (en orden de prioridad)
/// 1. Variable de entorno `SQL_PATH` (sobrescritura explícita).
/// 2. `/usr/share/ws-unp/ws.sql` (producción, instalación mediante paquete .deb).
/// 3. `db/ws.sql` (desarrollo, ejecución con `cargo run`).
///
/// # Parámetros
/// - `pool`: Pool de conexiones PostgreSQL ya establecido.
///
/// # Retorno
/// `Result<(), Box<dyn std::error::Error>>` – `Ok(())` si las migraciones se ejecutan correctamente,
/// o un error si no se puede leer el archivo o falla la ejecución SQL.
///
/// # Seguridad
/// - El archivo SQL se lee como cadena y se ejecuta directamente con `sqlx::raw_sql`,
///   por lo que no hay interpolación de variables (el script debe estar libre de placeholders).
/// - Las credenciales se toman del pool, no se exponen.
///
/// # Ejemplo de uso en producción
/// no_run
/// use ws_unp::db::{create_pool, run_migrations};
///
/// # async fn example() -> Result<(), Box<dyn std::error::Error>> {
/// let pool = create_pool("postgres://user:pass@localhost/sgdea").await?;
/// run_migrations(&pool).await?;
/// # Ok(())
/// # }
/// 
pub async fn run_migrations(pool: &PgPool) -> Result<(), Box<dyn std::error::Error>> {
    let sql_path = if let Ok(p) = std::env::var("SQL_PATH") {
        p
    } else if std::path::Path::new("/usr/share/ws-unp/ws.sql").exists() {
        "/usr/share/ws-unp/ws.sql".to_string()
    } else {
        "db/ws.sql".to_string()
    };

    let sql = std::fs::read_to_string(&sql_path).map_err(|e| {
        format!("No se pudo leer '{}': {}", sql_path, e)
    })?;

    sqlx::raw_sql(&sql).execute(pool).await?;
    tracing::info!("Migraciones ejecutadas desde '{}'", sql_path);
    Ok(())
}