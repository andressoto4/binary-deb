//! Consultas a PostgreSQL para ws-unp.
//!
//! Este módulo contiene todas las operaciones de base de datos utilizando la API
//! dinámica de `sqlx` (sin macros). Esto permite compilar sin necesidad de tener
//! una base de datos activa, ya que los tipos se verifican en tiempo de ejecución.
//!
//! # Organización
//! Las funciones se agrupan por temática:
//! - Usuarios (`upsert_user`)
//! - Mensajes de chat (`insert_message`, `offline_room_members`, `insert_undelivered`, `drain_undelivered`)
//! - Eventos offline (`insert_pending_event`, `drain_pending_events`)
//! - Salas (`create_room`, `get_room_name`, `join_room`)
//! - Notificaciones entre instancias (`pg_notify`)
//!
//! # Seguridad
//! - Los identificadores (UUID) se parsean desde string antes de usarlos en consultas,
//!   evitando inyección SQL.
//! - Las consultas utilizan bind parameters (`$1`, `$2`) para todos los valores dinámicos.
//! - Las operaciones batch como `insert_undelivered` usan `UNNEST` para evitar múltiples
//!   roundtrips y mantener integridad.
//!
//! # Notas de rendimiento
//! - `offline_room_members` usa `<> ALL($2)` para excluir una lista de usuarios en una sola consulta.
//! - `drain_pending_events` emplea `FOR UPDATE SKIP LOCKED` para evitar conflictos entre
//!   conexiones concurrentes que procesen eventos del mismo usuario.

use sqlx::{PgPool, Row};
use uuid::Uuid;
use crate::db::models::{PendingEvent, UndeliveredMessage};

// ── Usuarios 

/// Parsea un &str como UUID; devuelve error de sqlx si el formato es inválido.
///
/// Se usa internamente para convertir los strings de identificadores recibidos
/// desde el cliente en el tipo `Uuid` requerido por la base de datos.
///
/// # Parámetros
/// - `s`: Cadena que representa un UUID en formato estándar (ej: "123e4567-e89b-12d3-a456-426614174000").
///
/// # Retorno
/// `Result<Uuid, sqlx::Error>` – UUID parseado o error envuelto en `sqlx::Error::Decode`.
fn parse_uuid(s: &str) -> Result<Uuid, sqlx::Error> {
    Uuid::parse_str(s).map_err(|e| sqlx::Error::Decode(Box::new(e)))
}

/// Crea el usuario si no existe (upsert inocuo).
/// `user_id` debe ser un UUID válido en formato string.
///
/// # Parámetros
/// - `pool`: Pool de conexiones PostgreSQL.
/// - `user_id`: Identificador del usuario en formato string UUID.
///
/// # Comportamiento
/// Inserta el usuario en la tabla `users` solo si no existe ya. Esto permite
/// registrar usuarios automáticamente cuando se conectan por primera vez.
///
/// # Errores
/// - Si `user_id` no es un UUID válido, retorna `sqlx::Error::Decode`.
/// - Si falla la consulta por otro motivo, propaga el error.
pub async fn upsert_user(pool: &PgPool, user_id: &str) -> Result<(), sqlx::Error> {
    let uid = parse_uuid(user_id)?;
    sqlx::query("INSERT INTO users (id) VALUES ($1) ON CONFLICT (id) DO NOTHING")
        .bind(uid)
        .execute(pool)
        .await?;
    Ok(())
}

// ── Mensajes de chat 

/// Persiste un mensaje en la sala y devuelve su UUID.
///
/// # Parámetros
/// - `pool`: Pool de conexiones.
/// - `room_id`: UUID de la sala en formato string.
/// - `sender_id`: UUID del remitente en formato string.
/// - `content`: Contenido del mensaje (texto).
///
/// # Retorno
/// `Uuid` del mensaje recién insertado.
///
/// # Errores
/// - Si alguno de los UUID es inválido, retorna `sqlx::Error::Decode`.
/// - Si la inserción falla (ej: violación de clave foránea), propaga el error.
pub async fn insert_message(
    pool: &PgPool,
    room_id: &str,
    sender_id: &str,
    content: &str,
) -> Result<Uuid, sqlx::Error> {
    let rid = parse_uuid(room_id)?;
    let sid = parse_uuid(sender_id)?;
    let row = sqlx::query(
        "INSERT INTO messages (room_id, sender_id, content) VALUES ($1, $2, $3) RETURNING id",
    )
    .bind(rid)
    .bind(sid)
    .bind(content)
    .fetch_one(pool)
    .await?;
    Ok(row.get::<Uuid, _>("id"))
}

/// Devuelve los miembros de una sala que NO están en `online_users` (strings UUID).
///
/// # Parámetros
/// - `pool`: Pool de conexiones.
/// - `room_id`: UUID de la sala en formato string.
/// - `online_users`: Lista de UUIDs (en string) de usuarios actualmente conectados.
///
/// # Retorno
/// `Vec<String>` con los UUIDs de los miembros offline.
///
/// # Detalles
/// - La consulta usa `<> ALL($2)` para excluir todos los UUIDs pasados en el array.
/// - Los usuarios online que no son válidos (UUID mal formado) se filtran silenciosamente
///   antes de enviar la consulta, ya que no pueden estar en la base de datos.
///
/// # Errores
/// - Si `room_id` no es UUID válido, retorna `sqlx::Error::Decode`.
/// - Si falla la consulta, propaga el error.
pub async fn offline_room_members(
    pool: &PgPool,
    room_id: &str,
    online_users: &[String],
) -> Result<Vec<String>, sqlx::Error> {
    let rid = parse_uuid(room_id)?;
    // Convertir la lista de strings a UUIDs para el parámetro $2
    let online_uuids: Vec<Uuid> = online_users
        .iter()
        .filter_map(|s| Uuid::parse_str(s).ok())
        .collect();
    let rows = sqlx::query(
        "SELECT user_id FROM room_members WHERE room_id = $1 AND user_id <> ALL($2)",
    )
    .bind(rid)
    .bind(&online_uuids)
    .fetch_all(pool)
    .await?;
    Ok(rows
        .into_iter()
        .map(|r| r.get::<Uuid, _>("user_id").to_string())
        .collect())
}

/// Registra en batch los mensajes no entregados para los usuarios offline.
/// Usa UNNEST para un único roundtrip en lugar de N inserts individuales.
///
/// # Parámetros
/// - `pool`: Pool de conexiones.
/// - `message_id`: UUID del mensaje que no se pudo entregar.
/// - `user_ids`: Lista de UUIDs (en string) de los usuarios que deben recibirlo.
///
/// # Comportamiento
/// Inserta registros en `undelivered_messages` para cada usuario de la lista.
/// Si ya existe un registro para el mismo par `(message_id, user_id)`, se omite
/// (`ON CONFLICT DO NOTHING`).
///
/// # Errores
/// - Si algún UUID en `user_ids` es inválido, se filtra y no se inserta para ese usuario.
/// - Si la lista final queda vacía, la función retorna `Ok(())` sin ejecutar consulta.
/// - Cualquier otro error de base de datos se propaga.
pub async fn insert_undelivered(
    pool: &PgPool,
    message_id: Uuid,
    user_ids: &[String],
) -> Result<(), sqlx::Error> {
    let uids: Vec<Uuid> = user_ids
        .iter()
        .filter_map(|s| Uuid::parse_str(s).ok())
        .collect();
    if uids.is_empty() {
        return Ok(());
    }
    let message_ids: Vec<Uuid> = vec![message_id; uids.len()];
    sqlx::query(
        "INSERT INTO undelivered_messages (message_id, user_id)
         SELECT * FROM UNNEST($1::uuid[], $2::uuid[])
         ON CONFLICT DO NOTHING",
    )
    .bind(&message_ids)
    .bind(&uids)
    .execute(pool)
    .await?;
    Ok(())
}

/// Recupera y elimina los mensajes no entregados para un usuario.
///
/// # Parámetros
/// - `pool`: Pool de conexiones.
/// - `user_id`: UUID del usuario en formato string.
///
/// # Retorno
/// `Vec<UndeliveredMessage>` con los mensajes que estaban pendientes.
///
/// # Comportamiento
/// - Elimina los registros de `undelivered_messages` para el usuario.
/// - Al mismo tiempo, hace un `JOIN` con `messages` para obtener los datos completos.
/// - Los mensajes se devuelven en orden de envío (por `sent_at` de `messages`).
///
/// # Errores
/// - Si `user_id` no es UUID válido, retorna `sqlx::Error::Decode`.
/// - Si falla la consulta, propaga el error.
pub async fn drain_undelivered(
    pool: &PgPool,
    user_id: &str,
) -> Result<Vec<UndeliveredMessage>, sqlx::Error> {
    let uid = parse_uuid(user_id)?;
    let rows = sqlx::query_as::<_, UndeliveredMessage>(
        r#"
        DELETE FROM undelivered_messages u
        USING messages m
        WHERE u.message_id = m.id
          AND u.user_id = $1
        RETURNING
            u.id,
            u.message_id,
            m.room_id,
            m.sender_id,
            m.content,
            m.sent_at
        "#,
    )
    .bind(uid)
    .fetch_all(pool)
    .await?;
    Ok(rows)
}

// ── Eventos offline (notify / mail_update)

/// Encola un evento para un usuario offline.
///
/// # Parámetros
/// - `pool`: Pool de conexiones.
/// - `user_id`: UUID del usuario destino en formato string.
/// - `event_type`: Tipo de evento (ej: "notify", "mail_update").
/// - `payload`: Datos del evento en formato JSON.
///
/// # Comportamiento
/// Inserta un registro en `pending_events` con los datos proporcionados.
/// El evento será entregado cuando el usuario se conecte (mediante `drain_pending_events`).
///
/// # Errores
/// - Si `user_id` no es UUID válido, retorna `sqlx::Error::Decode`.
/// - Si falla la inserción, propaga el error.
pub async fn insert_pending_event(
    pool: &PgPool,
    user_id: &str,
    event_type: &str,
    payload: &serde_json::Value,
) -> Result<(), sqlx::Error> {
    let uid = parse_uuid(user_id)?;
    sqlx::query(
        "INSERT INTO pending_events (user_id, event_type, payload) VALUES ($1, $2, $3)",
    )
    .bind(uid)
    .bind(event_type)
    .bind(payload)
    .execute(pool)
    .await?;
    Ok(())
}

/// Recupera y elimina los eventos pendientes para un usuario.
///
/// # Parámetros
/// - `pool`: Pool de conexiones.
/// - `user_id`: UUID del usuario en formato string.
///
/// # Retorno
/// `Vec<PendingEvent>` con los eventos pendientes ordenados por `created_at`.
///
/// # Comportamiento
/// - Elimina los eventos del usuario en orden de creación.
/// - Usa `FOR UPDATE SKIP LOCKED` para que múltiples conexiones puedan procesar
///   eventos de distintos usuarios sin bloquearse mutuamente.
///
/// # Errores
/// - Si `user_id` no es UUID válido, retorna `sqlx::Error::Decode`.
/// - Si falla la consulta, propaga el error.
pub async fn drain_pending_events(
    pool: &PgPool,
    user_id: &str,
) -> Result<Vec<PendingEvent>, sqlx::Error> {
    let uid = parse_uuid(user_id)?;
    let rows = sqlx::query_as::<_, PendingEvent>(
        r#"
        DELETE FROM pending_events
        WHERE id IN (
            SELECT id FROM pending_events
            WHERE user_id = $1
            ORDER BY created_at
            FOR UPDATE SKIP LOCKED
        )
        RETURNING id, user_id, event_type, payload, created_at
        "#,
    )
    .bind(uid)
    .fetch_all(pool)
    .await?;
    Ok(rows)
}

// ── Salas

/// Crea una sala nueva y devuelve su UUID.
///
/// # Parámetros
/// - `pool`: Pool de conexiones.
/// - `name`: Nombre de la sala.
///
/// # Retorno
/// `Uuid` de la sala recién creada.
///
/// # Errores
/// - Si falla la inserción (ej: nombre duplicado si hay restricción única), propaga el error.
pub async fn create_room(pool: &PgPool, name: &str) -> Result<Uuid, sqlx::Error> {
    let row = sqlx::query("INSERT INTO rooms (name) VALUES ($1) RETURNING id")
        .bind(name)
        .fetch_one(pool)
        .await?;
    Ok(row.get::<Uuid, _>("id"))
}

/// Obtiene el nombre de una sala por su UUID. Devuelve None si no existe.
///
/// # Parámetros
/// - `pool`: Pool de conexiones.
/// - `room_id`: UUID de la sala en formato string.
///
/// # Retorno
/// `Option<String>` – nombre de la sala si existe, `None` en caso contrario.
///
/// # Errores
/// - Si `room_id` no es UUID válido, retorna `sqlx::Error::Decode`.
/// - Si falla la consulta, propaga el error.
pub async fn get_room_name(pool: &PgPool, room_id: &str) -> Result<Option<String>, sqlx::Error> {
    let rid = parse_uuid(room_id)?;
    let row = sqlx::query("SELECT name FROM rooms WHERE id = $1")
        .bind(rid)
        .fetch_optional(pool)
        .await?;
    Ok(row.map(|r| r.get::<String, _>("name")))
}

/// Añade un usuario a una sala (upsert inocuo si ya es miembro).
///
/// # Parámetros
/// - `pool`: Pool de conexiones.
/// - `room_id`: UUID de la sala.
/// - `user_id`: UUID del usuario.
///
/// # Comportamiento
/// Inserta la membresía solo si no existe ya. No retorna error si el par ya existía.
///
/// # Errores
/// - Si algún UUID es inválido, no se produce porque ya se han parseado previamente.
/// - Si falla la consulta por otro motivo, propaga el error.
pub async fn join_room(pool: &PgPool, room_id: Uuid, user_id: Uuid) -> Result<(), sqlx::Error> {
    sqlx::query(
        "INSERT INTO room_members (room_id, user_id) VALUES ($1, $2) ON CONFLICT DO NOTHING",
    )
    .bind(room_id)
    .bind(user_id)
    .execute(pool)
    .await?;
    Ok(())
}

/// Emite una notificación PostgreSQL en el canal 'ws_broadcast'.
///
/// Otras instancias del servidor que estén escuchando el canal recibirán el payload
/// y lo entregarán a sus usuarios locales (sincronización multi-instancia sin Redis).
///
/// # Parámetros
/// - `pool`: Pool de conexiones.
/// - `payload`: Cadena JSON que será transmitida a todas las instancias conectadas.
///
/// # Errores
/// - Si falla la consulta `pg_notify`, propaga el error.
pub async fn pg_notify(pool: &PgPool, payload: &str) -> Result<(), sqlx::Error> {
    sqlx::query("SELECT pg_notify('ws_broadcast', $1)")
        .bind(payload)
        .execute(pool)
        .await?;
    Ok(())
}