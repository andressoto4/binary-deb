//! Módulo principal del servidor ws-unp.
//!
//! Este módulo contiene el punto de entrada del servidor WebSocket y la lógica de inicialización.
//! Se espera que la configuración ya esté parseada desde `main` y se pase a `run_server`.
//!
//! # Flujo de ejecución
//! 1. Inicializa el sistema de logging (tracing).
//! 2. Registra información de configuración (puerto, URL de base de datos enmascarada, TLS).
//! 3. Crea un pool de conexiones a PostgreSQL.
//! 4. Si la flag `migrate` está activa, ejecuta las migraciones SQL.
//! 5. Inicia el servidor WebSocket, que corre hasta que se detenga.
//!
//! # Seguridad
//! - La URL de la base de datos se enmascara antes de loguearla, ocultando la contraseña.
//! - El pool de conexiones maneja reconexiones automáticas y límites de concurrencia.
//! - Las migraciones se ejecutan con el usuario configurado en la URL.

pub mod config;
pub mod types;
pub mod websocket;
pub mod db;
pub mod utils;
pub mod setup;

use crate::config::Config;
use crate::db::{create_pool, run_migrations};
use crate::utils::logger::init_logger;
use crate::websocket::server::start_websocket_server;

/// Enmascara la contraseña en una URL de conexión PostgreSQL para mostrarla en logs.
///
/// Reemplaza la parte de credenciales (usuario:contraseña) por `usuario:***`.
/// Si la URL no sigue el formato esperado o no se puede parsear, devuelve un marcador seguro.
///
/// # Formato esperado
/// ```
/// postgres://usuario:contraseña@host:puerto/db
/// postgresql://usuario:contraseña@host:puerto/db
/// ```
///
/// # Retorno
/// Una cadena con la contraseña oculta o un mensaje genérico si falla el parseo.
///
/// # Seguridad
/// Previene la filtración de contraseñas en logs.
fn mask_db_url(url: &str) -> String {
    // Intentar parsear la sección usuario:contraseña
    if let Some(rest) = url.strip_prefix("postgres://").or_else(|| url.strip_prefix("postgresql://")) {
        if let Some(at_pos) = rest.find('@') {
            let userinfo = &rest[..at_pos];
            let hostpart = &rest[at_pos..];
            let masked_userinfo = if let Some(colon) = userinfo.find(':') {
                format!("{}:***", &userinfo[..colon])
            } else {
                userinfo.to_string()
            };
            let prefix = if url.starts_with("postgresql://") { "postgresql://" } else { "postgres://" };
            return format!("{}{}{}", prefix, masked_userinfo, hostpart);
        }
    }
    // Si no se puede parsear, ocultar completamente para no filtrar nada
    "[conexión configurada]".to_string()
}

/// Punto de entrada del servidor.
///
/// Inicializa todos los subsistemas necesarios y lanza el servidor WebSocket.
///
/// # Parámetros
/// - `cfg`: Configuración ya parseada desde archivo y argumentos de línea de comandos.
///
/// # Retorno
/// `Ok(())` si el servidor se ejecuta sin errores y termina correctamente.
/// Un error en forma de `Box<dyn std::error::Error>` si ocurre alguna falla crítica.
///
/// # Comportamiento
/// 1. Inicializa el logger (tracing).
/// 2. Loggea información básica (puerto, URL de base de datos enmascarada, si TLS está habilitado).
/// 3. Crea un pool de conexiones a PostgreSQL usando `database_url`.
/// 4. Si `cfg.migrate` es verdadero, ejecuta las migraciones SQL sobre el pool.
/// 5. Inicia el servidor WebSocket, que corre indefinidamente hasta que se detenga (por señal, error, etc.).
///
/// # Seguridad
/// - La URL de base de datos se enmascara antes de mostrarla en logs.
/// - El pool de conexiones utiliza las opciones por defecto de `sqlx`, que incluyen límites de conexión y timeouts.
/// - Las migraciones se ejecutan dentro de una transacción si el driver lo soporta (sqlx).
///
/// # Errores
/// - Si el logger no puede inicializarse, se imprime un error y se continúa (depende de implementación de `init_logger`).
/// - Si el pool de conexiones no puede crearse, el error se propaga y el programa termina.
/// - Si las migraciones fallan, el error se propaga.
/// - Si el servidor WebSocket no puede iniciarse, el error se propaga.
pub async fn run_server(cfg: Config) -> Result<(), Box<dyn std::error::Error>> {
    // 1. Logger
    init_logger();

    tracing::info!("Puerto: {}", cfg.ws_port);
    tracing::info!("Base de datos: {}", mask_db_url(&cfg.database_url));
    tracing::info!("TLS: {}", cfg.use_tls());

    // 2. Pool de base de datos
    let pool = create_pool(&cfg.database_url).await?;
    tracing::info!("Pool Postgresql listo");

    // 3. Migraciones (solo si se pasó --migrate)
    if cfg.migrate {
        tracing::info!("Ejecutando migraciones SQL...");
        run_migrations(&pool).await?;
    }

    // 4. Servidor WebSocket
    start_websocket_server(&cfg, pool).await?;

    Ok(())
}