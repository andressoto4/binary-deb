//! Utilidades de logging para ws-unp.
//!
//! Este módulo proporciona una función de inicialización del logger basado en
//! `tracing_subscriber`. Se configura automáticamente para detectar si se está
//! ejecutando bajo systemd y ajusta el formato de salida en consecuencia.
//!
//! # Comportamiento
//! - Lee la variable de entorno `RUST_LOG` para establecer el nivel de filtro.
//!   Si no está definida, usa `info` por defecto.
//! - Detecta la presencia de `JOURNAL_STREAM` (variable establecida por systemd
//!   cuando la salida estándar/error se redirige al journal). En ese caso,
//!   desactiva colores ANSI y timestamps propios, ya que journald proporciona
//!   metadatos adicionales (PID, unidad, prioridad, timestamp).
//! - Usa un formato compacto (`compact()`) que muestra solo el mensaje y el nivel.
//!
//! # Ejemplo de uso
//! ```no_run
//! use ws_unp::utils::logger::init_logger;
//!
//! fn main() {
//!     init_logger();
//!     tracing::info!("Servidor iniciado");
//! }
//! ```

use tracing_subscriber::EnvFilter;

/// Inicializa el sistema de logging.
///
/// Configura un subscriber de `tracing` que:
/// - Lee el nivel de filtro de `RUST_LOG` (ej: `RUST_LOG=debug`). Si no está definido,
///   usa `info` por defecto.
/// - Detecta si se ejecuta bajo systemd verificando la variable de entorno `JOURNAL_STREAM`.
/// - En systemd, desactiva colores ANSI (`with_ansi(false)`) y timestamps propios (`without_time()`)
///   porque journald ya añade esos metadatos.
/// - En cualquier entorno, usa un formato compacto (`compact()`) que omite el target
///   (nombre del módulo) para reducir ruido, ya que se configura `with_target(false)`.
///
/// # Detalles de systemd
/// Cuando systemd redirige stdout/stderr al journal, establece la variable `JOURNAL_STREAM`.
/// Esto permite al logger saber que está en un entorno de servicio y adaptar la salida.
/// journald proporciona timestamp, PID, unidad de servicio y prioridad, por lo que no es
/// necesario duplicar esa información en los mensajes de log.
///
/// # Personalización
/// Para cambiar el formato o incluir más metadatos, se puede modificar la función
/// según necesidades, manteniendo la detección de systemd para producción.
pub fn init_logger() {
    let filter = EnvFilter::try_from_default_env()
        .unwrap_or_else(|_| EnvFilter::new("info"));

    // systemd establece JOURNAL_STREAM cuando stdin/stdout van al journal.
    let under_systemd = std::env::var("JOURNAL_STREAM").is_ok();

    if under_systemd {
        tracing_subscriber::fmt()
            .with_env_filter(filter)
            .with_target(false)
            .with_ansi(false)
            .without_time()
            .compact()
            .init();
    } else {
        tracing_subscriber::fmt()
            .with_env_filter(filter)
            .with_target(false)
            .compact()
            .init();
    }
}