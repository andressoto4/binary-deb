//! Módulo de utilidades generales para ws-unp.
//!
//! Este módulo agrupa funcionalidades transversales que no pertenecen a
//! ninguna capa específica (configuración, base de datos, WebSocket, etc.).
//!
//! # Submódulos
//! - `logger`: Inicialización y configuración del sistema de logging con `tracing`.

pub mod logger;