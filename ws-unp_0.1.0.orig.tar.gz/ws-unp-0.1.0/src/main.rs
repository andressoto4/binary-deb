//! Punto de entrada principal del binario ws-unp.
//!
//! Este módulo define la función `main` que orquesta el comportamiento según el subcomando
//! proporcionado por el usuario. Soporta:
//! - `setup`: Lanza el asistente interactivo de configuración inicial.
//! - (ninguno): Modo servidor por defecto, que carga la configuración y arranca el servidor WebSocket.
//!
//! La carga de argumentos se realiza mediante `load_cli` (definida en `config`), que retorna
//! una estructura `Cli` con los argumentos parseados.

use ws_unp::config::{load_cli, Commands, Config};
use ws_unp::run_server;

/// Punto de entrada principal.
///
/// Decide qué acción ejecutar según el subcomando recibido en línea de comandos.
///
/// # Comportamiento
/// - Si se pasa el subcomando `setup` (por ejemplo, `ws-unp setup`), se invoca
///   `ws_unp::setup::run_setup()` para lanzar el asistente interactivo.
/// - En caso contrario (ningún subcomando), se asume modo servidor:
///   se carga la configuración con `Config::from_serve_args(cli.serve)`,
///   se llama a `run_server` y, si falla, se imprime el error y se termina con código 1.
///
/// # Seguridad
/// La función `run_server` maneja permisos de archivos y conexiones seguras.
/// El asistente `setup` requiere permisos de superusuario para escribir en `/etc`.
#[tokio::main]
async fn main() {
    // Carga los argumentos de línea de comandos (usa clap).
    let cli = load_cli();

    // Decisión según el subcomando.
    match cli.command {
        // Asistente de configuración interactivo
        Some(Commands::Setup) => {
            ws_unp::setup::run_setup();
        }

        // Modo servidor (comportamiento por defecto)
        None => {
            // Construye la configuración a partir de los argumentos del modo serve.
            let cfg = Config::from_serve_args(cli.serve);
            // Lanza el servidor; si falla, imprime el error y sale con código de error.
            if let Err(e) = run_server(cfg).await {
                eprintln!("Error al ejecutar el servidor: {}", e);
                std::process::exit(1);
            }
        }
    }
}