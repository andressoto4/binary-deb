# Documentación Técnica de ws-unp

## Tabla de Contenidos

1. [Introducción](#introducción)
2. [Estructura del Proyecto](#estructura-del-proyecto)
3. [Esquema de Base de Datos](#esquema-de-base-de-datos)
4. [Archivo: `lib.rs`](#archivo-librs)
5. [Archivo: `main.rs`](#archivo-mainrs)
6. [Archivo: `config.rs`](#archivo-configrs)
7. [Archivo: `setup.rs`](#archivo-setuprs)
8. [Archivo: `types.rs`](#archivo-typesrs)
9. [Módulo: `db/`](#módulo-db)
   - [`db/mod.rs`](#dbmodrs)
   - [`db/models.rs`](#dbmodelsrs)
   - [`db/queries.rs`](#dbqueriesrs)
10. [Módulo: `websocket/`](#módulo-websocket)
    - [`websocket/server.rs`](#websocketserverrs)
    - [`websocket/handlers.rs`](#websockethandlersrs)
11. [Módulo: `utils/`](#módulo-utils)
    - [`utils/logger.rs`](#utilsloggerrs)
12. [Protocolo WebSocket](#protocolo-websocket)
13. [Sincronización Multi-instancia](#sincronización-multi-instancia)
14. [Consideraciones de Seguridad](#consideraciones-de-seguridad)

---

## Introducción

`ws-unp` es un servidor WebSocket desarrollado en Rust para la Unidad Nacional de Protección (UNP). Proporciona un canal de comunicación en tiempo real para el sistema de gestión documental (SGDEA), incluyendo salas de chat, notificaciones push dirigidas por usuario y alertas de bandeja de correo.

El servidor está diseñado para alta concurrencia: soporta múltiples instancias en paralelo comunicadas a través de PostgreSQL `LISTEN/NOTIFY`, maneja miles de conexiones simultáneas mediante el runtime asíncrono Tokio, y aplica rate limiting por usuario para protegerse de abuso.

**Tecnologías principales:**
- **Rust** con runtime asíncrono **Tokio**.
- **tokio-tungstenite** para el protocolo WebSocket (WS y WSS).
- **sqlx** con driver PostgreSQL para persistencia y sincronización multi-instancia.
- **rustls** para TLS sin dependencias nativas de OpenSSL.
- **clap** para la CLI y **dotenvy** para carga de variables de entorno desde `.env`.
- **DashMap** para estructuras de datos concurrentes lock-free.

---

## Estructura del Proyecto

```
src/
├── lib.rs              # Interfaz pública de la biblioteca; función run_server
├── main.rs             # Binario principal; parsea CLI y despacha subcomandos
├── config.rs           # Definición de CLI (clap) y estructuras de configuración validada
├── setup.rs            # Asistente interactivo de configuración inicial (sudo ws-unp setup)
├── types.rs            # Tipos de mensajes WebSocket (Command, Message)
├── db/
│   ├── mod.rs          # Pool de conexiones y función run_migrations
│   ├── models.rs       # Structs de filas de BD (PendingEvent, UndeliveredMessage)
│   └── queries.rs      # Todas las consultas SQL (sin macros, verificación en runtime)
├── websocket/
│   ├── mod.rs          # Re-exportaciones del módulo
│   ├── server.rs       # Ciclo de vida de conexiones, mapas compartidos, PG LISTEN
│   └── handlers.rs     # Lógica de enrutamiento y manejo de cada comando
└── utils/
    ├── mod.rs
    └── logger.rs       # Inicialización del sistema de logging (tracing)
```

---

## Esquema de Base de Datos

El archivo `db/ws.sql` define el esquema completo. Todas las sentencias usan `IF NOT EXISTS`, por lo que el script es idempotente y seguro de ejecutar múltiples veces.

**Extensión requerida:**
```sql
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
```
Habilita `gen_random_uuid()` para la generación automática de UUIDs versión 4.

### Tablas

#### `users`
Usuarios registrados en el sistema.

| Columna        | Tipo        | Descripción                                    |
|----------------|-------------|------------------------------------------------|
| `id`           | UUID PK     | Identificador único; auto-generado.            |
| `display_name` | TEXT        | Nombre visible (por defecto cadena vacía).     |
| `created_at`   | TIMESTAMPTZ | Marca de tiempo de creación.                   |

#### `rooms`
Salas de chat.

| Columna     | Tipo        | Descripción                      |
|-------------|-------------|----------------------------------|
| `id`        | UUID PK     | Identificador único.             |
| `name`      | TEXT        | Nombre de la sala.               |
| `created_at`| TIMESTAMPTZ | Marca de tiempo de creación.     |

#### `room_members`
Tabla de membresía: qué usuarios pertenecen a qué sala.

| Columna     | Tipo        | Descripción                              |
|-------------|-------------|------------------------------------------|
| `room_id`   | UUID FK     | Referencia a `rooms(id)` ON DELETE CASCADE. |
| `user_id`   | UUID FK     | Referencia a `users(id)` ON DELETE CASCADE. |
| `joined_at` | TIMESTAMPTZ | Cuándo se unió el usuario.               |

La clave primaria es `(room_id, user_id)`.

#### `messages`
Mensajes de chat persistidos.

| Columna     | Tipo        | Descripción                                                      |
|-------------|-------------|------------------------------------------------------------------|
| `id`        | UUID PK     | Identificador único del mensaje.                                 |
| `room_id`   | UUID FK     | Sala donde se envió (ON DELETE CASCADE).                         |
| `sender_id` | UUID        | Emisor (puede ser el sistema; sin FK obligatoria).               |
| `content`   | TEXT        | Texto del mensaje.                                               |
| `sent_at`   | TIMESTAMPTZ | Marca de tiempo de envío.                                        |

#### `pending_events`
Notificaciones y alertas de correo pendientes para usuarios offline.

| Columna      | Tipo        | Descripción                                                   |
|--------------|-------------|---------------------------------------------------------------|
| `id`         | UUID PK     | Identificador único.                                          |
| `user_id`    | UUID FK     | Destinatario (ON DELETE CASCADE).                             |
| `event_type` | TEXT        | Tipo de evento: `'notify'` o `'mail_update'`.                 |
| `payload`    | JSONB       | Datos del evento en formato JSON.                             |
| `created_at` | TIMESTAMPTZ | Marca de tiempo de creación.                                  |

Índice: `idx_pending_events_user ON (user_id, created_at)` para recuperación eficiente al reconexión.

#### `undelivered_messages`
Mensajes de chat no entregados a destinatarios que estaban offline en el momento del envío.

| Columna      | Tipo        | Descripción                                          |
|--------------|-------------|------------------------------------------------------|
| `id`         | UUID PK     | Identificador único.                                 |
| `message_id` | UUID FK     | Referencia a `messages(id)` ON DELETE CASCADE.       |
| `user_id`    | UUID FK     | Destinatario offline (ON DELETE CASCADE).            |
| `created_at` | TIMESTAMPTZ | Marca de tiempo.                                     |

Restricción única `(message_id, user_id)` para evitar duplicados. Índice: `idx_undelivered_user ON (user_id, created_at)`.

---

## Archivo: `lib.rs`

**Propósito:**
Define la interfaz pública de la biblioteca y contiene la función `run_server` que orquesta la inicialización completa del servidor.

### Módulos exportados

```rust
pub mod config;
pub mod types;
pub mod websocket;
pub mod db;
pub mod utils;
pub mod setup;
```

### Función auxiliar: `mask_db_url(url: &str) -> String`

Enmascara la contraseña en una URL de conexión PostgreSQL para mostrarla de forma segura en los logs.

**Formato esperado:**
```
postgres://usuario:contraseña@host:puerto/db
postgresql://usuario:contraseña@host:puerto/db
```

**Algoritmo:**
1. Detecta el prefijo `postgres://` o `postgresql://`.
2. Localiza el separador `@` para aislar la sección `usuario:contraseña`.
3. Reemplaza la contraseña por `***`, conservando el nombre de usuario, host, puerto y base de datos.
4. Si el parseo falla (URL con formato inesperado), devuelve `"[conexión configurada]"` para no filtrar información alguna.

**Seguridad:** Previene la filtración de contraseñas en logs, archivos de auditoría o salida de errores.

### Función principal: `run_server(cfg: Config) -> Result<(), Box<dyn std::error::Error>>`

Punto de entrada del servidor. Inicializa todos los subsistemas y lanza el servidor WebSocket.

**Flujo interno detallado:**

1. **Logger** — Llama a `init_logger()`. El nivel de log se controla con `RUST_LOG`; por defecto es `info`. Bajo systemd (presencia de `JOURNAL_STREAM`) desactiva colores ANSI y timestamps propios para evitar duplicados en journald.

2. **Logs de configuración** — Registra puerto, URL de BD enmascarada y estado TLS con `tracing::info!`.

3. **Pool de conexiones** — Llama a `create_pool(&cfg.database_url)`. Crea un pool de hasta **30 conexiones** concurrentes. Este límite es suficiente para 2 000+ usuarios porque el broadcast ocurre en memoria antes de tocar la BD.

4. **Migraciones** — Si `cfg.migrate` es `true`, ejecuta `run_migrations(&pool)`, que aplica `db/ws.sql` (o el path configurado en `SQL_PATH`). Seguro de ejecutar múltiples veces gracias a `IF NOT EXISTS`.

5. **Servidor WebSocket** — Llama a `start_websocket_server(&cfg, pool)` y queda en espera hasta que el servidor finalice (por señal del SO, error crítico, etc.).

**Retorno:**
- `Ok(())` al terminar normalmente.
- `Err(...)` ante fallo en pool, migraciones o servidor.

---

## Archivo: `main.rs`

**Propósito:**
Punto de entrada del binario. Configura el runtime asíncrono Tokio y despacha la ejecución según el subcomando recibido.

### Función `main` (async, `#[tokio::main]`)

**Descripción:**
1. Llama a `load_cli()` para cargar variables de `.env` (si existe) y parsear los argumentos de línea de comandos con `clap`.
2. Examina `cli.command`:
   - `Some(Commands::Setup)` → invoca `ws_unp::setup::run_setup()` (síncrono, interactivo).
   - `None` → modo servidor: construye `Config::from_serve_args(cli.serve)` y llama a `run_server(cfg)`. Si falla, imprime el error en stderr y termina con código de salida `1`.

**Manejo de errores:**
```rust
if let Err(e) = run_server(cfg).await {
    eprintln!("Error al ejecutar el servidor: {}", e);
    std::process::exit(1);
}
```
El código de salida `1` permite al supervisor (systemd, Docker, etc.) detectar fallos y reiniciar el servicio.

---

## Archivo: `config.rs`

**Propósito:**
Define la estructura de la línea de comandos usando `clap`, las estructuras de configuración y la lógica de carga, validación y construcción de la configuración final.

### Fuentes de configuración (orden de prioridad)

1. **Argumentos CLI** — `--ws-port 1520`, `--database-url ...`, etc.
2. **Variables de entorno** — `ws_port=1520`, `database_url=...`, `TLS_CERT_PATH=...`
3. **`/etc/ws-unp/ws-unp.conf`** — Archivo `EnvironmentFile` de systemd. systemd lo expone como variables de entorno al proceso; no se lee directamente en el código.
4. **`.env` en el directorio de trabajo** — Solo para desarrollo local, cargado con `dotenvy::dotenv()`.

### Estructura `Cli`

```rust
pub struct Cli {
    pub command: Option<Commands>,
    pub serve: ServeArgs,       // aplanado con #[command(flatten)]
}
```

La opción `flatten` hace que los argumentos de `ServeArgs` aparezcan directamente en la ayuda de `ws-unp`, sin necesidad de un subcomando.

### Enumeración `Commands`

```rust
pub enum Commands {
    Setup,    // sudo ws-unp setup
}
```

`Setup`: Lanza el asistente interactivo. Requiere permisos de superusuario para escribir en `/etc/ws-unp/` y ejecutar comandos como el usuario `postgres`.

### Estructura `ServeArgs`

Argumentos del modo servidor con sus fuentes y valores por defecto:

| Campo            | Tipo            | Env              | Defecto | Descripción                                                         |
|------------------|-----------------|------------------|---------|---------------------------------------------------------------------|
| `ws_port`        | `String`        | `ws_port`        | `1520`  | Puerto TCP donde escucha el servidor WebSocket.                     |
| `database_url`   | `Option<String>`| `database_url`   | —       | URL completa de PostgreSQL. Obligatoria en modo servidor.           |
| `migrate`        | `bool`          | —                | `false` | Si `true`, ejecuta el esquema SQL antes de iniciar.                 |
| `tls_cert_path`  | `Option<String>`| `TLS_CERT_PATH`  | —       | Ruta al certificado PEM (habilita WSS si también hay clave).        |
| `tls_key_path`   | `Option<String>`| `TLS_KEY_PATH`   | —       | Ruta a la clave privada PEM.                                        |

Los campos sensibles (`database_url`, `tls_cert_path`, `tls_key_path`) usan `hide_env_values = true` para que sus valores no aparezcan en la salida de `--help`.

### Estructura `Config`

```rust
pub struct Config {
    pub ws_port:       String,
    pub database_url:  String,
    pub migrate:       bool,
    pub tls_cert_path: Option<String>,
    pub tls_key_path:  Option<String>,
}
```

**Métodos:**

#### `Config::from_serve_args(args: ServeArgs) -> Self`

Construye y valida la configuración. La función es una fábrica que termina el proceso ante cualquier error de validación, garantizando que una instancia de `Config` siempre está en estado válido.

1. Desenvuelve `database_url`; si es `None`, imprime un mensaje de ayuda (`sudo ws-unp setup`) y llama a `process::exit(1)`.
2. Construye el struct.
3. Llama a `validate_or_exit()`.

#### `Config::use_tls(&self) -> bool`

Retorna `true` únicamente si tanto `tls_cert_path` como `tls_key_path` están presentes. El servidor arranca en modo WSS solo cuando ambos están configurados.

#### `Config::validate_or_exit(&self)`

Validaciones con salida de proceso ante error:

- **`database_url`** no debe contener la cadena `"CAMBIE_ESTA_CLAVE"` (placeholder del archivo de configuración de ejemplo). Si la contiene, el proceso termina con un mensaje que recuerda ejecutar `sudo ws-unp setup`.
- **`ws_port`** debe parsear a `u16` (rango 1–65535). Un puerto inválido termina el proceso con un mensaje descriptivo.

### Función `load_cli() -> Cli`

```rust
pub fn load_cli() -> Cli {
    dotenv().ok();   // silencioso si no hay .env
    Cli::parse()
}
```

`dotenv().ok()` ignora silenciosamente la ausencia del archivo `.env`, lo que es correcto en producción donde la configuración llega de `/etc/ws-unp/ws-unp.conf` vía systemd.

---

## Archivo: `setup.rs`

**Propósito:**
Asistente interactivo (subcomando `sudo ws-unp setup`) que guía al administrador en la configuración inicial: creación del usuario/BD PostgreSQL, escritura del archivo de configuración, ejecución de migraciones y habilitación del servicio systemd.

**Constantes:**
```rust
const CONF_DIR:  &str = "/etc/ws-unp";
const CONF_PATH: &str = "/etc/ws-unp/ws-unp.conf";
```

### Función principal: `run_setup()`

Orquesta todo el proceso en 6 pasos numerados visibles al usuario:

**Paso 0 — Verificación de acceso:**
`ensure_write_access()` comprueba que el proceso tiene acceso de escritura al sistema de archivos necesario. Si no, aborta con un mensaje claro antes de que el usuario responda preguntas.

**Paso 0b — Banner:**
Muestra un recuadro ASCII con el nombre del asistente y las instrucciones básicas de uso.

**Recopilación de parámetros** (antes del resumen):

| Parámetro  | Función de captura        | Defecto     | Validación                              |
|------------|---------------------------|-------------|------------------------------------------|
| `ws_port`  | `prompt_validated`        | `"1520"`    | Parseable como `u16` (1–65535).          |
| `pg_host`  | `prompt`                  | `"localhost"`| Ninguna (puede ser hostname o IP).      |
| `pg_port`  | `prompt_validated`        | `"5432"`    | Parseable como `u16`.                   |
| `db_name`  | `prompt_identifier`       | `"sgdea"`   | Solo alfanuméricos y `_`; no inicia con dígito. |
| `db_user`  | `prompt_identifier`       | `"ws_unp"`  | Ídem.                                   |
| `db_pass`  | `rpassword::prompt_password`| (generada)| Si vacío, se llama a `generate_password()`. |

La contraseña se lee con `rpassword` (sin eco en terminal) y nunca se muestra en claro ni se registra en logs.

La URL de base de datos se construye como:
```
postgres://{db_user}:{db_pass}@{pg_host}:{pg_port}/{db_name}
```

**Paso 1 — PostgreSQL:**
Si `pg_host` es `localhost`, `127.0.0.1` o `::1` → llama a `setup_postgres()`. De lo contrario muestra instrucciones manuales para crear el usuario y la BD en el servidor remoto.

**Paso 2 — Archivo de configuración:**
Llama a `write_conf(&ws_port, &database_url)`. Genera `/etc/ws-unp/ws-unp.conf` con comentarios y permisos `640 root:ws-unp`.

**Paso 3 — Migraciones SQL:**
Pregunta si desea ejecutar `CREATE TABLE IF NOT EXISTS`. Si el usuario acepta, llama a `run_migrations(&database_url)` que ejecuta `psql` con el archivo SQL. Si rechaza, muestra el comando equivalente: `sudo -u ws-unp ws-unp --migrate`.

**Paso 4 — Servicio systemd:**
Pregunta si desea habilitar e iniciar el servicio. Si acepta, llama a `enable_service()` que ejecuta `systemctl enable --now ws-unp`. Si rechaza, muestra el comando equivalente.

**Cancelación:**
Si el usuario responde `"n"` al resumen de configuración, se imprime "Cancelado" y se llama a `process::exit(0)` sin haber realizado ningún cambio.

### Funciones de entrada

#### `prompt(question: &str, default: &str) -> String`

Lee una línea de stdin con `stdin.lock().read_line()`. Si la entrada está vacía (solo Enter), devuelve `default`. Hace flush de stdout antes de leer para garantizar que el prompt sea visible en terminales no-TTY o con buffering.

#### `prompt_validated(question, default, validate) -> String`

Bucle infinito que llama a `prompt` y ejecuta la función `validate`. Si `validate` devuelve `Err(msg)`, imprime el mensaje de error y vuelve a preguntar. El default también pasa por el validador.

#### `prompt_identifier(question: &str, default: &str) -> String`

Especialización de `prompt_validated` con la regla de identificadores PostgreSQL:
- Todos los caracteres deben ser alfanuméricos o `_`.
- No puede comenzar con un dígito ASCII.

**Seguridad:** Previene inyección SQL indirecta al limitar estrictamente los caracteres en nombres de usuario y base de datos.

### Generación de contraseña: `generate_password() -> String`

**Algoritmo con fallback:**
1. Ejecuta `openssl rand -base64 32` (32 bytes = 256 bits de entropía).
2. Filtra los caracteres no alfanuméricos del output base64 (elimina `+`, `/`, `=`, `\n`).
3. Toma hasta 32 caracteres. Si hay al menos 16, los usa como contraseña.
4. **Fallback:** Si `openssl` no está disponible o falla, genera un UUID v4 y elimina los guiones (128 bits de entropía, 32 caracteres hexadecimales).

### PostgreSQL local: `setup_postgres(db_user, db_pass, db_name)`

**Pre-condición:** Solo se invoca cuando el host es local.

**Flujo:**
1. Ejecuta `pg_isready` para verificar disponibilidad de PostgreSQL. Si falla, muestra los comandos manuales equivalentes y retorna.
2. Escapa la contraseña con `db_pass.replace('\'', "''")` para literales de cadena SQL.
3. Construye y ejecuta un bloque `DO $$ BEGIN ... END $$` que crea el usuario si no existe y actualiza su contraseña si ya existe:
   ```sql
   DO $$ BEGIN
     IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'ws_unp') THEN
       CREATE USER ws_unp WITH PASSWORD '***';
     ELSE
       ALTER USER ws_unp WITH PASSWORD '***';
     END IF;
   END $$;
   ```
4. Verifica si la BD ya existe con `SELECT COUNT(*) FROM pg_database WHERE datname = '...'`.
5. Si no existe, ejecuta `CREATE DATABASE {db_name} OWNER {db_user}`.

### Ejecución SQL como `postgres`: `pg_exec_stdin(sql)` y `pg_query_stdin(sql)`

Ambas funciones utilizan el mismo mecanismo seguro:

```
su -s /bin/sh postgres -c "psql [-q|-tA]"
```

El SQL se escribe en el **stdin** del proceso hijo, nunca en la línea de comandos. Esto evita:
- Exposición de contraseñas en `ps aux` o `/proc/*/cmdline`.
- Problemas de escapado de la shell con caracteres especiales.

`pg_exec_stdin` usa `psql -q` (modo silencioso) y hereda stderr para que el usuario vea los errores.
`pg_query_stdin` usa `psql -tA` (solo datos, sin encabezados ni alineación) y captura stdout para parsear el entero resultado.

### Escritura de configuración: `write_conf(ws_port, database_url)`

**Flujo:**
1. Si `/etc/ws-unp/` no existe, lo crea con `fs::create_dir_all` y ajusta permisos con `chmod 750` y `chown root:ws-unp`.
2. Genera el contenido del archivo con comentarios explicativos de cada variable.
3. Escribe el archivo con `fs::write`.
4. Ajusta permisos: `chmod 640` y `chown root:ws-unp` via `Command::new("chmod/chown")`.
5. Si cualquier paso falla, imprime el error y llama a `process::exit(1)`.

**Permisos resultantes:**
- Directorio `/etc/ws-unp/`: `drwxr-x--- root ws-unp` (750) — El grupo `ws-unp` puede listar pero no escribir.
- Archivo `ws-unp.conf`: `-rw-r----- root ws-unp` (640) — Solo root puede escribir; el grupo `ws-unp` solo puede leer.

### Estructura visual: `print_box(lines: &[&str])`

Genera un recuadro de asteriscos centrado con el contenido recibido.

**Algoritmo:**
1. Calcula el ancho máximo entre todas las líneas (en caracteres Unicode, no bytes).
2. Añade 4 para los bordes (`"* "` izquierdo y `" *"` derecho).
3. Imprime separador superior, luego cada línea centrada con padding calculado como `(ancho_total - len_línea - 4) / 2`, y finalmente el separador inferior.

---

## Archivo: `types.rs`

**Propósito:**
Define los tipos de mensajes del protocolo WebSocket. Utiliza `serde` con serialización/deserialización JSON en formato `camelCase`.

### Enumeración `Command`

```rust
#[derive(Serialize, Deserialize, Debug, Clone, PartialEq, Eq)]
#[serde(rename_all = "camelCase")]
pub enum Command { ... }
```

La anotación `rename_all = "camelCase"` hace que las variantes se serialicen como `join`, `createRoom`, `joinRoom`, `msg`, `notify`, `mailUpdate`, `leave`.

| Variante     | JSON         | Campos requeridos en `Message`      | Descripción                                                              |
|--------------|--------------|--------------------------------------|--------------------------------------------------------------------------|
| `Join`       | `"join"`     | `user_id`                            | Identificarse al conectar. Debe ser el primer mensaje enviado.           |
| `CreateRoom` | `"createRoom"`| `content` (nombre de la sala)       | Crear una sala nueva. El servidor responde con `room_created` + UUID.    |
| `JoinRoom`   | `"joinRoom"` | `room_id`                            | Unirse a una sala existente. Registra la membresía en BD.                |
| `Msg`        | `"msg"`      | `room_id`, `content`                 | Mensaje de chat a la sala. Se persiste y se hace broadcast.              |
| `Notify`     | `"notify"`   | `user_id`, `content`                 | Notificación puntual dirigida a un usuario específico.                   |
| `MailUpdate` | `"mailUpdate"`| `user_id`                           | Alerta de nueva actividad en bandeja de correo.                          |
| `Leave`      | `"leave"`    | —                                    | Desconexión limpia. El servidor cierra la conexión de forma ordenada.    |

### Estructura `Message`

```rust
#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct Message {
    pub command: Command,
    #[serde(default)] pub user_id:  Option<String>,
    #[serde(default)] pub room_id:  Option<String>,
    #[serde(default)] pub sender:   Option<String>,
    #[serde(default)] pub content:  Option<String>,
}
```

`#[serde(default)]` en todos los campos opcionales significa que pueden omitirse completamente del JSON sin causar error de deserialización; toman el valor `None` automáticamente.

**Ejemplo de mensaje `Join`:**
```json
{"command": "join", "userId": "550e8400-e29b-41d4-a716-446655440000"}
```

**Ejemplo de mensaje `Msg`:**
```json
{"command": "msg", "roomId": "f47ac10b-...", "content": "Hola a todos"}
```

---

## Módulo: `db/`

### `db/mod.rs`

Punto de entrada del módulo de base de datos. Exporta los submódulos y define las dos funciones de infraestructura de BD.

#### `create_pool(database_url: &str) -> Result<PgPool, sqlx::Error>`

```rust
PgPoolOptions::new()
    .max_connections(30)
    .connect(database_url)
    .await
```

- **30 conexiones máximas** son suficientes para 2 000+ usuarios concurrentes porque el broadcast de mensajes ya ocurrió en memoria (DashMap) antes de que la consulta llegue a la BD.
- Las conexiones se crean bajo demanda y se reutilizan; sqlx maneja reconexiones automáticas.

#### `run_migrations(pool: &PgPool) -> Result<(), Box<dyn std::error::Error>>`

Ejecuta el esquema SQL contra la BD. Es idempotente por el uso de `IF NOT EXISTS`.

**Resolución de ruta (en orden de prioridad):**
1. Variable de entorno `SQL_PATH` — Sobreescritura explícita para entornos especiales.
2. `/usr/share/ws-unp/ws.sql` — Ruta del paquete `.deb` en producción.
3. `db/ws.sql` — Ruta relativa para desarrollo con `cargo run`.

Usa `sqlx::raw_sql(&sql).execute(pool)` para ejecutar el script completo en un único roundtrip.

### `db/models.rs`

Define los structs que mapean filas de BD a Rust con `sqlx::FromRow`.

#### `PendingEvent`

```rust
pub struct PendingEvent {
    pub id:          Uuid,
    pub user_id:     Uuid,
    pub event_type:  String,         // 'notify' | 'mail_update'
    pub payload:     serde_json::Value,  // JSONB
    pub created_at:  OffsetDateTime,
}
```

El campo `payload` se almacena como `JSONB` en PostgreSQL y se deserializa como `serde_json::Value` en Rust, permitiendo flexibilidad en la estructura del payload.

#### `UndeliveredMessage`

```rust
pub struct UndeliveredMessage {
    pub id:         Uuid,
    pub message_id: Uuid,
    pub room_id:    Uuid,
    pub sender_id:  Uuid,
    pub content:    String,
    pub sent_at:    OffsetDateTime,
}
```

Este struct usa un JOIN implícito: la consulta `drain_undelivered` hace `DELETE FROM undelivered_messages USING messages` y retorna campos de ambas tablas, por lo que el struct incluye campos de `messages` (`room_id`, `sender_id`, `content`, `sent_at`).

### `db/queries.rs`

**Nota de diseño:** Todas las consultas usan la API dinámica de sqlx (sin macros `query!`), evitando la necesidad de `DATABASE_URL` en tiempo de compilación. La verificación de tipos ocurre en runtime.

#### Función auxiliar: `parse_uuid(s: &str) -> Result<Uuid, sqlx::Error>`

Convierte un `&str` a `Uuid`. En caso de error, devuelve un `sqlx::Error::Decode` con el mensaje de error de UUID, permitiendo propagarlo como error de sqlx en `?`.

#### Consultas de usuarios

**`upsert_user(pool, user_id)`**
```sql
INSERT INTO users (id) VALUES ($1) ON CONFLICT (id) DO NOTHING
```
Crea el usuario si no existe. El `user_id` debe ser un UUID válido; si no lo es, `parse_uuid` falla y se registra el error pero no se itera.

#### Consultas de mensajes de chat

**`insert_message(pool, room_id, sender_id, content) -> Result<Uuid>`**
```sql
INSERT INTO messages (room_id, sender_id, content) VALUES ($1, $2, $3) RETURNING id
```
Persiste un mensaje y devuelve su UUID recién generado para la posterior inserción en `undelivered_messages`.

**`offline_room_members(pool, room_id, online_users) -> Result<Vec<String>>`**
```sql
SELECT user_id FROM room_members WHERE room_id = $1 AND user_id <> ALL($2)
```
Convierte la lista de `online_users` (strings) a `Vec<Uuid>` y usa el operador `<> ALL($2)` de PostgreSQL para excluirlos eficientemente en un único query. Devuelve los UUIDs como strings para uniformidad con el resto del código.

**`insert_undelivered(pool, message_id, user_ids)`**
```sql
INSERT INTO undelivered_messages (message_id, user_id)
SELECT * FROM UNNEST($1::uuid[], $2::uuid[])
ON CONFLICT DO NOTHING
```
Usa `UNNEST` con dos arrays paralelos para insertar N registros en un único roundtrip de red, en lugar de N inserts individuales. `ON CONFLICT DO NOTHING` previene duplicados.

**`drain_undelivered(pool, user_id) -> Result<Vec<UndeliveredMessage>>`**
```sql
DELETE FROM undelivered_messages u
USING messages m
WHERE u.message_id = m.id AND u.user_id = $1
RETURNING u.id, u.message_id, m.room_id, m.sender_id, m.content, m.sent_at
```
Operación atómica que recupera y elimina en un solo query, evitando condiciones de carrera donde un mensaje podría entregarse dos veces.

#### Consultas de eventos offline

**`insert_pending_event(pool, user_id, event_type, payload)`**
```sql
INSERT INTO pending_events (user_id, event_type, payload) VALUES ($1, $2, $3)
```
Encola notificaciones o alertas de correo para entrega futura cuando el usuario se reconecte.

**`drain_pending_events(pool, user_id) -> Result<Vec<PendingEvent>>`**
```sql
DELETE FROM pending_events
WHERE id IN (
    SELECT id FROM pending_events
    WHERE user_id = $1
    ORDER BY created_at
    FOR UPDATE SKIP LOCKED
)
RETURNING id, user_id, event_type, payload, created_at
```
Usa `FOR UPDATE SKIP LOCKED` para seguridad en entornos multi-instancia: si dos instancias intentan entregar eventos al mismo usuario simultáneamente (reconexión con load balancer), cada una toma filas diferentes sin bloqueos. Los eventos se devuelven ordenados por `created_at`.

#### Consultas de salas

**`create_room(pool, name) -> Result<Uuid>`** — Inserta y devuelve UUID de la nueva sala.

**`get_room_name(pool, room_id) -> Result<Option<String>>`** — Consulta el nombre de una sala. Devuelve `None` si no existe.

**`join_room(pool, room_id, user_id)`** — `INSERT ... ON CONFLICT DO NOTHING` para añadir membresía de forma idempotente.

**`pg_notify(pool, payload)`** — Ejecuta `SELECT pg_notify('ws_broadcast', $1)` para enviar el mensaje a todas las instancias suscritas al canal `ws_broadcast` de PostgreSQL.

---

## Módulo: `websocket/`

### `websocket/server.rs`

El módulo más complejo. Gestiona el ciclo de vida de conexiones, los mapas sincronizados en memoria y la integración con PG LISTEN/NOTIFY.

#### Constantes

```rust
const HEARTBEAT_INTERVAL: Duration = Duration::from_secs(30);
const CHANNEL_CAPACITY:   usize    = 256;
```

- **`HEARTBEAT_INTERVAL`**: Cada 30 segundos el servidor envía un `Ping` WebSocket. Si no recibe `Pong` antes del siguiente tick, cierra la conexión (cliente muerto o red caída).
- **`CHANNEL_CAPACITY`**: El canal `mpsc` por conexión guarda hasta 256 mensajes en buffer. Si el buffer se llena (cliente lento), los mensajes nuevos se descartan con `try_send` en lugar de bloquear el thread, aplicando backpressure.

#### Tipos públicos compartidos

Todos son alias de `Arc<DashMap<...>>`, lo que permite clonarlos con costo O(1) y compartirlos entre tareas Tokio de forma concurrente sin locks explícitos:

```rust
pub type UserMap     = Arc<DashMap<String, Vec<mpsc::Sender<WsMessage>>>>;
pub type RoomMap     = Arc<DashMap<String, String>>;
pub type RoomUserMap = Arc<DashMap<String, HashSet<String>>>;
pub type CacheMap    = Arc<DashMap<String, String>>;
pub type RateLimitMap= Arc<DashMap<String, (u32, std::time::Instant)>>;

pub const RATE_LIMIT_MAX:         u32 = 20;
pub const RATE_LIMIT_WINDOW_SECS: u64 = 1;
```

| Tipo           | Clave        | Valor                            | Uso                                                               |
|----------------|--------------|----------------------------------|-------------------------------------------------------------------|
| `UserMap`      | `user_id`    | `Vec<Sender>` (multi-tab)        | Entregar mensajes a un usuario. Soporta múltiples conexiones.     |
| `RoomMap`      | `user_id`    | `room_id`                        | Sala actual de cada usuario.                                      |
| `RoomUserMap`  | `room_id`    | `HashSet<user_id>`               | Índice inverso para broadcast O(n_miembros).                      |
| `CacheMap`     | `room_id`    | `name`                           | Caché L1 de nombres de sala; evita queries repetidos a BD.        |
| `RateLimitMap` | `user_id`    | `(count, window_start)`          | Rate limiting: máx 20 mensajes por segundo.                       |

#### `ServerState`

```rust
struct ServerState {
    user_map, room_map, room_user_map, cache_map, rate_limit_map,
    instance_id: Arc<String>,  // UUID único por proceso
    pool: PgPool,
}
```

Se clona antes de cada `tokio::spawn`, compartiendo los `Arc` con costo mínimo. `instance_id` es un UUID v4 generado al inicio; lo usa el PG LISTENER para ignorar notificaciones propias.

#### Función `start_websocket_server(cfg, pool)`

Punto de entrada público del servidor:

1. Crea el `TcpListener` en `0.0.0.0:{ws_port}`.
2. Inicializa `ServerState`.
3. Lanza tarea PG LISTENER en background con `tokio::spawn`.
4. **Si TLS está habilitado:**
   - Llama a `build_tls_acceptor(cfg)` que carga certificado y clave con `rustls_pemfile`.
   - Por cada nueva conexión: aplica handshake TLS → WebSocket upgrade → `handle_ws_stream`.
   - Registra advertencia si TLS está deshabilitado (texto plano `ws://`).
5. **Sin TLS:** Hace WebSocket upgrade directamente.

#### Función `build_tls_acceptor(cfg)`

Carga los certificados PEM del archivo `TLS_CERT_PATH` usando `rustls_pemfile::certs()` (devuelve `Iterator<Item=Result<CertificateDer>>`). Falla explícitamente si el archivo no contiene certificados. Carga la clave privada con `rustls_pemfile::private_key()`. Configura `ServerConfig::builder().with_no_client_auth()` (sin autenticación mTLS) y crea el `TlsAcceptor`.

#### Ciclo de vida de una conexión: `handle_ws_stream`

```
Fase 1: Esperar Join
Fase 2: Registrar en mapas
Fase 3: Entregar mensajes y eventos pendientes
Fase 4: Bucle principal (select! sobre stream WS, canal rx, heartbeat)
Fase 5: Limpiar mapas al desconectar
```

**Fase 1 — Esperar `Join`:**
Bucle que lee mensajes hasta recibir `Command::Join` con `user_id` presente. Cualquier otro mensaje recibe la respuesta `{"error":"Send Join first"}`. Si la conexión se cierra antes del Join, se retorna sin registrar nada.

**Fase 2 — Registro:**
- `user_map.entry(user_id).or_default().push(tx)` — Añade el sender del canal a la lista del usuario (soporte multi-tab).
- `room_map.entry(user_id).or_insert("general")` — Sala por defecto.
- `room_user_map.entry("general").or_default().insert(user_id)` — Registro en índice inverso.

**Fase 3 — Entrega de pendientes:**
`deliver_pending` llama a `drain_undelivered` y `drain_pending_events`. Para cada mensaje offline envía un JSON con `"event": "offline_msg"`. Para cada evento offline envía el payload almacenado. Después envía `{"event":"connected","user_id":"..."}` como confirmación de sesión establecida.

**Fase 4 — Bucle principal con `tokio::select!`:**

```
┌─────────────────────────────┐
│  tokio::select!             │
│  ├── ws_stream.next()       │  Mensajes del cliente
│  ├── rx.recv()              │  Mensajes reenviados (de otros usuarios/instancias)
│  └── heartbeat.tick()       │  Ping/Pong cada 30 s
└─────────────────────────────┘
```

- **`WsMessage::Text`** — Llama a `handle_message` y responde `"ACK"` al cliente.
- **`WsMessage::Pong`** — Resetea `pending_pong = false` (conexión viva).
- **`WsMessage::Close`** — Registra motivo con code y reason y sale del bucle.
- **`WsMessage::Binary`** — Ignorado (debug log).
- **`rx.recv()`** — Reenvía mensajes de broadcast al cliente; si falla (cliente desconectado), sale.
- **`heartbeat.tick()`** — Si `pending_pong` era `true` → timeout → cierra. Si no, envía `Ping`.

**Fase 5 — Limpieza:**
Remueve el sender cerrado del `user_map`. Si todos los senders del usuario están cerrados (último tab/dispositivo), remueve al usuario de `user_map`, `room_map` y `room_user_map`. Esto previene memory leaks en sesiones largas.

**Eliminación de zombies durante broadcast:**
Cuando `handle_msg` hace broadcast a los miembros de una sala, detecta senders cuyo canal está cerrado (`senders.iter().all(|s| s.is_closed())`). Los acumula en un vector `stale` y los elimina de los mapas después del broadcast, sin bloquear el loop principal.

#### Función `deliver_pending`

Combina `drain_undelivered` y `drain_pending_events` en la reconexión:
- Los mensajes offline se envían como `{"event":"offline_msg","room_id":...,"sender_id":...,"content":...,"sent_at":...}`.
- Los eventos offline se envían como `{"event":{event_type},"payload":{...},"created_at":...}`.

#### PG LISTEN/NOTIFY: `start_pg_listener`

Tarea permanente que escucha el canal `ws_broadcast`:

```
loop {
    PgListener::connect(db_url).await   // Nueva conexión dedicada
    listener.listen("ws_broadcast")
    loop {
        listener.recv() → handle_pg_notification
        on error: break (reconectar)
    }
    sleep(2s)  // backoff antes de reconectar
}
```

Esta tarea usa una **conexión PostgreSQL dedicada** (no del pool) para el `LISTEN` permanente. El backoff de 2 s previene el flood de intentos de reconexión ante fallos transitorios de red.

#### Función `handle_pg_notification`

Filtra el mensaje por `origin`:
```rust
if data["origin"].as_str() == Some(my_instance) { return; }
```
Si el `origin` coincide con el `instance_id` de la instancia actual, el mensaje ya fue entregado localmente y se ignora. De lo contrario, hace broadcast local a todos los miembros de la sala usando `user_map` y `room_user_map`.

### `websocket/handlers.rs`

#### Función `handle_message`

Enrutador central. Deserializa el JSON con `serde_json::from_str::<Message>` y delega según `msg.command`:

| Comando      | Handler              |
|--------------|----------------------|
| `Msg`        | `handle_msg`         |
| `Notify`     | `handle_notify`      |
| `MailUpdate` | `handle_mail_update` |
| `CreateRoom` | `handle_create_room` |
| `JoinRoom`   | `handle_join_room`   |
| `Join`/`Leave`| (no-op: ya tratados en el bucle principal) |

#### Función auxiliar: `deliver_to_user`

```rust
fn deliver_to_user(user_id: &str, msg: WsMessage, user_map: &UserMap) -> bool
```

Itera sobre todos los senders del usuario (multi-tab), filtra los cerrados, y llama a `try_send` en cada uno. Devuelve `true` si al menos un sender estaba activo. El `bool` permite a los handlers decidir si encolar el mensaje en BD (usuario offline).

#### Función auxiliar: `switch_room`

Mueve al usuario de su sala actual a la nueva en los mapas en memoria:
1. Obtiene la sala actual de `room_map`.
2. Si es la misma sala → no-op (return temprano).
3. Elimina al usuario de `room_user_map[old_room]`.
4. Actualiza `room_map[user_id] = new_room`.
5. Añade al usuario a `room_user_map[new_room]`.

#### Rate limiting: `rate_limited`

```rust
fn rate_limited(user_id: &str, rate_limit_map: &RateLimitMap) -> bool
```

Ventana deslizante simple: almacena `(count, window_start)` por usuario:
- Si el tiempo desde `window_start` supera `RATE_LIMIT_WINDOW_SECS` (1 s), reinicia la ventana con `count = 1`.
- Si `count > RATE_LIMIT_MAX` (20), registra warning y devuelve `true` (descartar mensaje).
- `RATE_LIMIT_MAX = 20` mensajes/segundo por usuario es un límite razonable para chat humano.

#### `handle_msg`

1. Verifica que `room_id` esté presente; si no, log warning y retorna.
2. Verifica rate limit.
3. **Broadcast local O(miembros_sala):** Itera `room_user_map[room_id]`, excluye al emisor, y usa `try_send` para cada sender. Maneja `TrySendError::Full` (canal lleno → cliente lento → warning log) y elimina zombies.
4. **Snapshot de online:** Antes de salir del contexto, captura la lista actual de `user_map` como `Vec<String>` para pasarla a la tarea de fondo.
5. **Tarea en background (`tokio::spawn`):** Todo el trabajo de BD se delega a una tarea Tokio independiente, eliminando el cuello de botella en el camino crítico del mensaje:
   - Clona `pool`, `room_id`, `sender_id`, `content` e `instance_id` (coste O(1) para el pool; O(n) solo para los strings, que son cortos).
   - **`pg_notify`:** Publica en `ws_broadcast` con `origin` = `instance_id` para que otras instancias reenvíen a sus conexiones locales.
   - **Persistencia:** Solo si `room_id` y `sender_id` son UUIDs válidos: llama a `insert_message`, luego `offline_room_members` (usando el snapshot capturado), y finalmente `insert_undelivered` con UNNEST para los offline.

> **Impacto en latencia:** el `ACK` se envía al cliente inmediatamente después del broadcast en memoria, sin esperar los 4 round-trips a PostgreSQL (`pg_notify` + `insert_message` + `offline_room_members` + `insert_undelivered`). Bajo carga alta, esto evita que la BD sea el cuello de botella de toda la cadena de mensajes.

#### `handle_notify`

Entrega `{"event":"notify","from":sender_id,"content":...}` al `target` (user_id).
Si `deliver_to_user` retorna `false` (usuario offline) y el `target` es UUID válido, encola en `pending_events` con `event_type = "notify"`. El encolado se realiza dentro de un `tokio::spawn` para no bloquear el enrutador: se clonan `pool`, `target` y `payload` (todos baratos) y la inserción en BD ocurre en background.

#### `handle_mail_update`

Similar a `handle_notify` pero con payload `{"event":"mail_update","content":...}` y `event_type = "mail_update"`. El encolado en `pending_events` para usuarios offline también se realiza en un `tokio::spawn`.

#### `handle_create_room`

1. Verifica que `content` (nombre) esté presente y no sea solo espacios.
2. Llama a `create_room(pool, name)` para insertar en BD y obtener UUID.
3. Guarda el nombre en `cache_map` para evitar queries futuros.
4. Llama a `join_room` en BD si el sender es UUID válido.
5. Llama a `switch_room` en memoria.
6. Responde con `{"event":"room_created","room_id":...,"name":...}`.

#### `handle_join_room`

1. Verifica que `room_id` esté presente.
2. Si `room_id` es UUID valid: llama a `join_room` en BD. Resuelve el nombre: primero busca en `cache_map` (L1), si no hay, consulta BD y guarda en caché.
3. Llama a `switch_room` en memoria.
4. Responde con `{"event":"room_joined","room_id":...,"name":...}`.

---

## Módulo: `utils/`

### `utils/logger.rs`

#### `init_logger()`

Inicializa el subsistema de logging con `tracing_subscriber`.

**Nivel de log:** Controlado por la variable de entorno `RUST_LOG` (ej: `RUST_LOG=debug`). Si no está definida, usa `"info"` como defecto mediante `EnvFilter::try_from_default_env().unwrap_or_else(|_| EnvFilter::new("info"))`.

**Detección de systemd:** Comprueba la presencia de `JOURNAL_STREAM` en el entorno. systemd establece esta variable cuando el stdin/stdout del proceso van al journal.

| Contexto   | `with_ansi` | `without_time` | Justificación                                                         |
|------------|-------------|----------------|-----------------------------------------------------------------------|
| systemd    | `false`     | Sí             | journald añade timestamps propios; los colores ANSI ensucian el log. |
| Terminal   | `true`      | No             | Salida legible con colores y timestamps en desarrollo.               |

Ambos modos usan `.compact()` (formato de una línea por evento) y `.with_target(false)` (omite el módulo emisor del log).

---

## Protocolo WebSocket

### Flujo de conexión típico

```
Cliente                          Servidor
  │                                 │
  │──── WS Connect ────────────────►│
  │                                 │  (espera Join)
  │──── {"command":"join",          │
  │      "userId":"<uuid>"} ───────►│
  │                                 │  upsert_user()
  │                                 │  registrar en mapas
  │                                 │  deliver_pending()
  │◄─── {"event":"connected",       │
  │      "userId":"<uuid>"} ────────│
  │                                 │
  │──── {"command":"createRoom",    │
  │      "content":"Sala A"} ──────►│  create_room() → UUID
  │◄─── {"event":"room_created",    │  join_room()
  │      "roomId":"...",            │  switch_room()
  │      "name":"Sala A"} ──────────│
  │                                 │
  │──── {"command":"msg",           │
  │      "roomId":"...",            │
  │      "content":"Hola"} ────────►│  broadcast local
  │◄─── "ACK" ──────────────────────│  pg_notify()
  │                                 │  insert_message()
  │                                 │  insert_undelivered() (offline)
  │                                 │
  │     (cada 30 s)                 │
  │◄─── Ping ───────────────────────│
  │──── Pong ──────────────────────►│
  │                                 │
  │──── WS Close ──────────────────►│  limpiar mapas
```

### Eventos del servidor al cliente

| Evento          | JSON                                                                 | Descripción                                              |
|-----------------|----------------------------------------------------------------------|----------------------------------------------------------|
| `connected`     | `{"event":"connected","userId":"<id>"}`                             | Confirmación de sesión iniciada.                         |
| `msg`           | `{"event":"msg","roomId":"...","sender":"...","content":"..."}`      | Mensaje de chat recibido.                                |
| `notify`        | `{"event":"notify","from":"...","content":"..."}`                   | Notificación puntual.                                    |
| `mail_update`   | `{"event":"mail_update","content":"..."}`                           | Alerta de bandeja de correo.                             |
| `room_created`  | `{"event":"room_created","roomId":"...","name":"..."}`              | Confirmación de sala creada.                             |
| `room_joined`   | `{"event":"room_joined","roomId":"...","name":"..."}`               | Confirmación de unión a sala.                            |
| `offline_msg`   | `{"event":"offline_msg","roomId":...,"senderId":...,"content":...,"sentAt":...}` | Mensaje recibido mientras estaba offline. |
| `ACK`           | `"ACK"` (texto plano)                                               | Confirmación de recepción de cualquier mensaje.         |
| `error`         | `{"error":"<descripción>"}`                                         | Error de protocolo.                                      |

---

## Sincronización Multi-instancia

ws-unp puede ejecutarse en múltiples instancias detrás de un load balancer. La sincronización se realiza mediante PostgreSQL `LISTEN/NOTIFY`:

```
Instancia A            PostgreSQL           Instancia B
    │                      │                     │
    │── pg_notify() ──────►│                     │
    │   canal: ws_broadcast │                     │
    │   {origin:"id-A",...} │                     │
    │                      │── NOTIFY ───────────►│
    │                      │                     │  origin != id-B → procesar
    │                      │                     │  broadcast local
```

**Flujo cuando un usuario conectado a la Instancia B recibe un mensaje enviado a la Instancia A:**
1. Instancia A hace `handle_msg`: broadcast local a sus conexiones activas + `pg_notify`.
2. PostgreSQL notifica a todos los listeners del canal `ws_broadcast`.
3. Instancia B recibe la notificación, verifica que `origin != instance_id` propio.
4. Instancia B hace broadcast local a los miembros de la sala que tiene conectados.

**Fiabilidad:** Los mensajes enviados mientras todos los usuarios de una sala están offline se persisten en `undelivered_messages` y se entregan al reconectarse desde cualquier instancia.

---

## Consideraciones de Seguridad

### Configuración y secretos
- **`/etc/ws-unp/ws-unp.conf`** se escribe con permisos `640 root:ws-unp`. Solo el usuario de sistema `ws-unp` (que ejecuta el servicio) y root pueden leerlo. Contiene la `DATABASE_URL` con la contraseña en texto plano (protegida por el sistema de archivos).
- El directorio `/etc/ws-unp/` tiene permisos `750 root:ws-unp`.
- La variable `database_url` se oculta en la ayuda de la CLI (`hide_env_values = true`) y se enmascara en logs mediante `mask_db_url()`.

### Generación de contraseñas
- Se usa `openssl rand -base64 32` (256 bits de entropía) con filtrado a caracteres alfanuméricos.
- Fallback: UUID v4 (128 bits de entropía). Ambos son suficientemente seguros para contraseñas de bases de datos.

### PostgreSQL local
- Creación de usuario via `su postgres -c psql` con SQL enviado por stdin. Evita exponer la contraseña en `ps aux` (argumentos CLI) y en el historial de la shell.
- Validación de identifiers con `prompt_identifier` previene inyección SQL en nombres de usuario y base de datos.

### Validaciones de entrada
- `validate_or_exit()` rechaza el placeholder `CAMBIE_ESTA_CLAVE` y puertos inválidos.
- `prompt_identifier` restringe caracteres para nombres de BD/usuario.
- Rate limiting (20 msg/s por usuario) protege contra flood de mensajes.
- Los mensajes binarios WebSocket se ignoran silenciosamente.

### TLS
- Soporte WSS mediante rustls (implementación pura Rust, sin OpenSSL).
- El servidor emite una advertencia `warn!` si TLS está deshabilitado y hay clientes externos potenciales.
- No se configura autenticación mTLS (`with_no_client_auth`).

### Multi-instancia
- `FOR UPDATE SKIP LOCKED` en `drain_pending_events` previene entrega duplicada de eventos en despliegues multi-nodo.
- El campo `origin` en pg_notify previene que una instancia procese sus propios mensajes dos veces.

### Manejo de conexiones
- Heartbeat con Ping/Pong detecta conexiones muertas y las cierra en `≤ 60 s` (30 s de intervalo + siguiente tick).
- Backpressure via `try_send` con buffer de 256 mensajes descarta mensajes para clientes lentos en lugar de bloquear el servidor.
- Limpieza automática de zombies durante el broadcast evita memory leaks.