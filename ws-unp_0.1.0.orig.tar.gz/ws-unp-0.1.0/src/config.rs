//! Módulo de configuración y línea de comandos para ws-unp.
//!
//! Este módulo define la estructura de la CLI utilizando `clap`, las opciones de configuración
//! y la lógica de carga y validación de parámetros. Soporta dos modos de ejecución:
//! - **Modo servidor** (por defecto): inicia el servidor WebSocket con la configuración provista.
//! - **Modo setup**: lanza un asistente interactivo que configura el entorno por primera vez.
//!
//! # Fuentes de configuración (modo servidor)
//! Las opciones se resuelven con el siguiente orden de prioridad:
//! 1. Argumentos de línea de comandos (ej: `--ws-port 1520`).
//! 2. Variables de entorno (ej: `ws_port=1520`).
//! 3. Archivo `/etc/ws-unp/ws-unp.conf` (EnvironmentFile de systemd) – no se lee directamente aquí,
//!    sino que systemd las expone como variables de entorno.
//! 4. Archivo `.env` en el directorio de trabajo (solo desarrollo, gracias a `dotenvy`).
//!
//! # Seguridad
//! - Las opciones sensibles como `database_url` se ocultan en la ayuda de la CLI (`hide_env_values`).
//! - Se validan puertos y se rechazan placeholders inseguros.
//! - La configuración final no expone contraseñas en los logs (véase `mask_db_url` en otro módulo).

use clap::{Args, Parser, Subcommand};
use dotenvy::dotenv;

/// CLI principal de ws-unp.
///
/// Sin subcomando → inicia el servidor WebSocket.
/// Con subcomando `setup` → lanza el asistente de configuración interactivo.
///
/// Fuentes de configuración (orden de prioridad para el modo servidor):
///   1. Argumento de consola       --ws-port 1520
///   2. Variable de entorno        ws_port=1520
///   3. EnvironmentFile systemd    /etc/ws-unp/ws-unp.conf  (producción)
///   4. Archivo .env en el cwd                               (desarrollo)
#[derive(Parser, Debug)]
#[command(
    name    = "ws-unp",
    about   = "Servidor WebSocket para el gestor documental",
    version
)]
pub struct Cli {
    #[command(subcommand)]
    pub command: Option<Commands>,

    #[command(flatten)]
    pub serve: ServeArgs,
}

/// Subcomandos disponibles.
#[derive(Subcommand, Debug)]
pub enum Commands {
    /// Asistente interactivo de configuración inicial.
    ///
    /// Crea el usuario y base de datos en PostgreSQL, escribe
    /// /etc/ws-unp/ws-unp.conf y opcionalmente inicia el servicio.
    ///
    /// Requiere permisos de superusuario:
    ///   sudo ws-unp setup
    Setup,
}

/// Argumentos del modo servidor (usados cuando no se pasa ningún subcomando).
#[derive(Args, Debug)]
pub struct ServeArgs {
    /// Puerto en el que escucha el servidor WebSocket.
    #[arg(long, env = "ws_port", default_value = "1520")]
    pub ws_port: String,

    /// URL de conexión a PostgreSQL.
    /// Ejemplo: postgres://usuario:clave@localhost:5432/mi_base
    /// En producción, definir en /etc/ws-unp/ws-unp.conf o como variable de entorno.
    #[arg(long, env = "database_url", hide_env_values = true)]
    pub database_url: Option<String>,

    /// Ejecutar el esquema SQL antes de iniciar el servidor.
    /// Útil en el primer despliegue. En producción ejecutar con:
    ///   sudo -u ws-unp ws-unp --migrate
    #[arg(long, default_value_t = false)]
    pub migrate: bool,

    /// Ruta al archivo PEM con el certificado TLS (habilita WSS).
    #[arg(long, env = "TLS_CERT_PATH", hide_env_values = true)]
    pub tls_cert_path: Option<String>,

    /// Ruta al archivo PEM con la clave privada TLS.
    #[arg(long, env = "TLS_KEY_PATH", hide_env_values = true)]
    pub tls_key_path: Option<String>,
}

/// Configuración validada del servidor.
/// Solo se construye cuando no se usa el subcomando `setup`.
#[derive(Debug)]
pub struct Config {
    pub ws_port:      String,
    pub database_url: String,
    pub migrate:      bool,
    pub tls_cert_path: Option<String>,
    pub tls_key_path:  Option<String>,
}

impl Config {
    /// Construye y valida la configuración del servidor a partir de los
    /// argumentos ya parseados. Sale con un mensaje claro ante errores.
    ///
    /// # Comportamiento
    /// - Toma los valores de `ServeArgs`.
    /// - Si `database_url` es `None`, imprime un error y sale con código 1.
    /// - Luego valida que `database_url` no contenga el placeholder inseguro `CAMBIE_ESTA_CLAVE`.
    /// - Valida que `ws_port` sea un número entre 1 y 65535.
    /// - Si alguna validación falla, imprime un mensaje de error y termina el proceso.
    ///
    /// # Retorno
    /// Una instancia de `Config` lista para usar.
    pub fn from_serve_args(args: ServeArgs) -> Self {
        let database_url = args.database_url.unwrap_or_else(|| {
            eprintln!(
                "Error: --database-url es obligatorio para iniciar el servidor.\n\
                 Configure el servicio ejecutando:\n\
                   sudo ws-unp setup"
            );
            std::process::exit(1);
        });

        let cfg = Self {
            ws_port: args.ws_port,
            database_url,
            migrate:      args.migrate,
            tls_cert_path: args.tls_cert_path,
            tls_key_path:  args.tls_key_path,
        };
        cfg.validate_or_exit();
        cfg
    }

    /// `true` si están configurados certificado y clave TLS (modo WSS).
    pub fn use_tls(&self) -> bool {
        self.tls_cert_path.is_some() && self.tls_key_path.is_some()
    }

    /// Valida los campos de configuración y sale con error si alguno es inválido.
    ///
    /// # Validaciones
    /// - `database_url` no debe contener la cadena `CAMBIE_ESTA_CLAVE`.
    /// - `ws_port` debe ser un número u16 válido (1–65535).
    fn validate_or_exit(&self) {
        if self.database_url.contains("CAMBIE_ESTA_CLAVE") {
            eprintln!(
                "Error de configuración: database_url contiene el placeholder \
                 'CAMBIE_ESTA_CLAVE'.\n\
                 Ejecute el asistente de configuración:\n\
                   sudo ws-unp setup"
            );
            std::process::exit(1);
        }
        if self.ws_port.parse::<u16>().is_err() {
            eprintln!(
                "Error de configuración: ws_port='{}' no es un puerto válido (1-65535).",
                self.ws_port
            );
            std::process::exit(1);
        }
    }
}

/// Carga el .env (solo en desarrollo) y parsea la CLI.
///
/// # Comportamiento
/// - Intenta cargar un archivo `.env` del directorio actual usando `dotenvy::dotenv()`.
///   En producción, si no existe, simplemente se ignora (no hay error).
/// - Luego parsea los argumentos de línea de comandos con `Cli::parse()`.
///
/// # Retorno
/// Una estructura `Cli` con los argumentos ya procesados.
pub fn load_cli() -> Cli {
    dotenv().ok(); // silencioso si no hay .env — correcto en producción
    Cli::parse()
}