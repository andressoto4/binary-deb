//! Definición de los tipos de mensajes WebSocket y comandos utilizados por el servidor ws-unp.
//!
//! Este módulo contiene las estructuras de datos que serializan/deserializan los mensajes
//! intercambiados entre el cliente y el servidor. Los mensajes utilizan JSON con formato
//! `camelCase` para los nombres de campo.
//!
//! # Flujo de mensajes típico
//! 1. El cliente envía un `Command::Join` para autenticarse.
//! 2. Luego puede enviar `Command::CreateRoom` para crear salas o `Command::JoinRoom` para unirse.
//! 3. Dentro de una sala, envía `Command::Msg` para mensajes de chat.
//! 4. El servidor puede enviar `Command::Notify` o `Command::MailUpdate` como notificaciones.
//! 5. Al finalizar, el cliente envía `Command::Leave` para cerrar la conexión limpiamente.

use serde::{Deserialize, Serialize};

/// Comandos que puede enviar un cliente al servidor (o viceversa).
///
/// Define las acciones posibles en el protocolo WebSocket. Cada variante tiene un significado
/// específico y espera ciertos campos en el mensaje contenedor (`Message`).
#[derive(Serialize, Deserialize, Debug, Clone, PartialEq, Eq)]
#[serde(rename_all = "camelCase")]
pub enum Command {
    /// Identificarse al conectar.
    ///
    /// El cliente debe enviar este comando con su `user_id` en `Message.user_id`.
    /// Si la identificación es exitosa, el servidor podrá asociar la conexión con el usuario.
    Join,

    /// Crear una sala nueva.
    ///
    /// Se requiere `content` en `Message` con el nombre de la sala.
    /// El servidor responde con el UUID de la sala creada (generalmente en `room_id`).
    CreateRoom,

    /// Unirse a una sala existente.
    ///
    /// Se requiere `room_id` en `Message` para especificar la sala.
    JoinRoom,

    /// Mensaje de chat dirigido a una sala.
    ///
    /// Se requiere `room_id` para identificar la sala y `content` con el texto del mensaje.
    /// Opcionalmente se puede incluir `sender` para indicar el emisor (aunque el servidor
    /// ya conoce al usuario por la conexión).
    Msg,

    /// Notificación puntual dirigida a un usuario destino.
    ///
    /// El servidor puede enviar este comando a un cliente específico con `user_id` y `content`.
    Notify,

    /// Alerta de cambio en bandeja de correo, dirigida a un usuario destino.
    ///
    /// Similar a `Notify`, pero específica para notificaciones de correo interno.
    MailUpdate,

    /// El cliente se desconecta limpiamente.
    ///
    /// Al enviar este comando, el servidor cierra la conexión de forma ordenada.
    Leave,
}

/// Estructura principal del mensaje de entrada/salida.
///
/// Contiene un comando y los campos opcionales necesarios según el comando.
/// Los campos se serializan/deserializan en formato camelCase.
#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct Message {
    /// Comando que define la acción del mensaje.
    pub command: Command,

    /// Identificador de usuario.
    ///
    /// Se usa en:
    /// - `Join`: para identificarse.
    /// - `Notify`, `MailUpdate`: para indicar el destinatario.
    /// - `Msg` (alternativa a `sender`): podría representar el emisor.
    #[serde(default)]
    pub user_id: Option<String>,

    /// Identificador de sala.
    ///
    /// Se usa en:
    /// - `JoinRoom`: sala a la que se desea unir.
    /// - `Msg`: sala donde se envía el mensaje.
    #[serde(default)]
    pub room_id: Option<String>,

    /// Emisor del mensaje (solo para `Msg`).
    ///
    /// Proporciona una alternativa a `user_id` para mantener compatibilidad.
    #[serde(default)]
    pub sender: Option<String>,

    /// Contenido del mensaje o información adicional.
    ///
    /// Se usa en:
    /// - `CreateRoom`: nombre de la sala.
    /// - `Msg`: texto del mensaje.
    /// - `Notify`, `MailUpdate`: contenido de la notificación.
    #[serde(default)]
    pub content: Option<String>,
}