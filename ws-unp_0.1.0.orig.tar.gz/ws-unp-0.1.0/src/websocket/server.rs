//! Servidor WebSocket principal para ws-unp.
//!
//! Este módulo implementa el servidor WebSocket que acepta conexiones de clientes,
//! gestiona el ciclo de vida de cada conexión, y coordina la entrega de mensajes
//! tanto a nivel local como entre instancias mediante PostgreSQL LISTEN/NOTIFY.
//!
//! # Características
//! - Soporte para TLS/WSS mediante certificados PEM.
//! - Heartbeat con ping/pong para detectar conexiones muertas.
//! - Rate limiting por usuario para evitar flooding.
//! - Sincronización multi-instancia sin Redis usando `pg_notify`.
//! - Manejo de múltiples conexiones por usuario (varios tabs/dispositivos).
//!
//! # Estructuras en memoria (compartidas entre conexiones)
//! - `UserMap`: asocia `user_id` a una lista de canales de salida (senders).
//! - `RoomMap`: asocia `user_id` a la sala actual.
//! - `RoomUserMap`: asocia `room_id` a un conjunto de `user_id` (para broadcast eficiente).
//! - `CacheMap`: caché de nombres de sala (`room_id` → nombre).
//! - `RateLimitMap`: contadores por usuario para rate limiting.
//!
//! # Flujo de una conexión
//! 1. Se acepta una nueva conexión TCP (con o sin TLS).
//! 2. Se realiza el handshake WebSocket.
//! 3. Se espera un mensaje `Join` con `user_id` válido.
//! 4. Se registra el canal de salida en `UserMap` y se asigna la sala por defecto (`general`).
//! 5. Se entregan mensajes y eventos pendientes (almacenados en BD).
//! 6. Se entra en el bucle principal: procesa mensajes entrantes, envía heartbeats, reenvía desde otras instancias.
//! 7. Al desconectar, se limpian los mapas.

use std::collections::HashSet;
use std::fs::File;
use std::io::BufReader;
use std::net::SocketAddr;
use std::sync::Arc;
use std::time::Duration;

use dashmap::DashMap;
use futures::{SinkExt, StreamExt};
use sqlx::PgPool;
use sqlx::postgres::PgListener;
use tokio::net::TcpListener;
use tokio::sync::mpsc;
use tokio::time::interval_at;
use tokio_tungstenite::{accept_async, WebSocketStream};
use tokio_tungstenite::tungstenite::protocol::Message as WsMessage;
use tracing::{debug, error, info, warn};
use uuid::Uuid;

use rustls::ServerConfig;
use rustls::pki_types::{CertificateDer, PrivateKeyDer};
use tokio_rustls::TlsAcceptor;

use crate::config::Config;
use crate::websocket::handlers::handle_message;

// ── Constantes

/// Intervalo entre pings del servidor para detectar conexiones muertas.
/// Si un cliente no responde con un pong dentro de este tiempo, la conexión se cierra.
const HEARTBEAT_INTERVAL: Duration = Duration::from_secs(30);

/// Capacidad del canal mpsc por conexión.
/// Con `try_send`, mensajes sobre este límite se descartan (backpressure).
const CHANNEL_CAPACITY: usize = 256;

// ── Tipos públicos

/// Mapa global: `user_id` → lista de canales de salida para todas sus conexiones activas.
/// Permite múltiples dispositivos/tabs por usuario.
pub type UserMap = Arc<DashMap<String, Vec<mpsc::Sender<WsMessage>>>>;

/// Mapa global: `user_id` → sala activa (ID de sala).
pub type RoomMap = Arc<DashMap<String, String>>;

/// Mapa global: `room_id` → conjunto de `user_id` presentes en esa sala.
/// Útil para broadcast eficiente sin recorrer todos los usuarios.
pub type RoomUserMap = Arc<DashMap<String, HashSet<String>>>;

/// Caché en memoria: `room_id` → nombre de sala.
pub type CacheMap = Arc<DashMap<String, String>>;

/// Rate limiting por usuario: (mensajes en ventana actual, inicio de ventana).
pub type RateLimitMap = Arc<DashMap<String, (u32, std::time::Instant)>>;

/// Número máximo de mensajes permitidos por ventana de tiempo.
pub const RATE_LIMIT_MAX: u32 = 20;

/// Duración de la ventana de rate limiting (segundos).
pub const RATE_LIMIT_WINDOW_SECS: u64 = 1;

// ── Estado compartido del servidor

/// Agrupa todos los mapas compartidos entre conexiones y recursos externos.
///
/// Todos los campos son `Arc<_>` o tipos clonables, por lo que `ServerState` se puede clonar
/// baratamente y pasar a cada tarea de conexión.
#[derive(Clone)]
struct ServerState {
    user_map: UserMap,
    room_map: RoomMap,
    room_user_map: RoomUserMap,
    cache_map: CacheMap,
    rate_limit_map: RateLimitMap,
    instance_id: Arc<String>,
    pool: PgPool,
}

impl ServerState {
    /// Crea un nuevo estado compartido con todos los mapas vacíos y un ID de instancia único.
    fn new(pool: PgPool) -> Self {
        Self {
            user_map: Arc::new(DashMap::new()),
            room_map: Arc::new(DashMap::new()),
            room_user_map: Arc::new(DashMap::new()),
            cache_map: Arc::new(DashMap::new()),
            rate_limit_map: Arc::new(DashMap::new()),
            instance_id: Arc::new(Uuid::new_v4().to_string()),
            pool,
        }
    }
}

// ── Entrada pública

/// Inicia el servidor WebSocket.
///
/// # Parámetros
/// - `cfg`: Configuración del servidor (puerto, TLS, etc.).
/// - `pool`: Pool de conexiones a PostgreSQL.
///
/// # Comportamiento
/// 1. Escucha en `0.0.0.0:cfg.ws_port`.
/// 2. Si TLS está habilitado, configura un acaptador con los certificados especificados.
/// 3. Lanza una tarea en segundo plano que escucha notificaciones de PostgreSQL (`ws_broadcast`)
///    para sincronizar mensajes entre instancias.
/// 4. Para cada conexión entrante, crea una tarea que ejecuta `handle_ws_stream`.
///
/// # Errores
/// - Si no se puede bindear el puerto, retorna error.
/// - Si TLS está habilitado pero los archivos son inválidos o no existen, retorna error.
pub async fn start_websocket_server(
    cfg: &Config,
    pool: PgPool,
) -> Result<(), Box<dyn std::error::Error>> {
    let addr = format!("0.0.0.0:{}", cfg.ws_port);
    let listener = TcpListener::bind(&addr).await?;
    let state = ServerState::new(pool);

    info!("Instancia ID: {}", state.instance_id);

    // Tarea de sincronización multi-instancia vía PG LISTEN/NOTIFY.
    {
        let s = state.clone();
        let db_url = cfg.database_url.clone();
        tokio::spawn(async move {
            start_pg_listener(db_url, s.instance_id, s.user_map, s.room_user_map).await;
        });
    }

    if cfg.use_tls() {
        let acceptor = build_tls_acceptor(cfg)?;
        info!("Servidor WebSocket escuchando en wss://{}", addr);
        while let Ok((stream, peer_addr)) = listener.accept().await {
            let acceptor = acceptor.clone();
            let s = state.clone();
            tokio::spawn(async move {
                match acceptor.accept(stream).await {
                    Ok(tls_stream) => match accept_async(tls_stream).await {
                        Ok(ws) => {
                            info!("Conexión WSS: {}", peer_addr);
                            handle_ws_stream(ws, peer_addr, s).await;
                        }
                        Err(e) => error!("Handshake WSS {}: {}", peer_addr, e),
                    },
                    Err(e) => error!("TLS {}: {}", peer_addr, e),
                }
            });
        }
    } else {
        warn!(
            "TLS deshabilitado — el servidor escucha en texto plano (ws://{}). \
             Active TLS_CERT_PATH y TLS_KEY_PATH si hay clientes externos.",
            addr
        );
        info!("Servidor WebSocket escuchando en ws://{}", addr);
        while let Ok((stream, peer_addr)) = listener.accept().await {
            let s = state.clone();
            tokio::spawn(async move {
                match accept_async(stream).await {
                    Ok(ws) => {
                        info!("Conexión WS: {}", peer_addr);
                        handle_ws_stream(ws, peer_addr, s).await;
                    }
                    Err(e) => error!("Handshake WS {}: {}", peer_addr, e),
                }
            });
        }
    }

    Ok(())
}

// ── TLS ─────────────────────────────────────────────────────────────────────

/// Construye un acaptador TLS a partir de los caminos de certificado y clave en `cfg`.
///
/// # Parámetros
/// - `cfg`: Configuración con `tls_cert_path` y `tls_key_path`.
///
/// # Retorno
/// `Ok(TlsAcceptor)` listo para usar, o un error si no se pueden leer los archivos
/// o el formato es inválido.
///
/// # Seguridad
/// - No se requiere autenticación de cliente (`with_no_client_auth`).
/// - Se usa `rustls` con configuraciones seguras por defecto.
fn build_tls_acceptor(cfg: &Config) -> Result<TlsAcceptor, Box<dyn std::error::Error>> {
    let cert_path = cfg.tls_cert_path.as_deref().ok_or("TLS_CERT_PATH no configurado")?;
    let key_path  = cfg.tls_key_path.as_deref().ok_or("TLS_KEY_PATH no configurado")?;

    let certs: Vec<CertificateDer<'static>> = {
        let mut r = BufReader::new(File::open(cert_path)?);
        rustls_pemfile::certs(&mut r).collect::<Result<_, _>>()?
    };
    if certs.is_empty() {
        return Err("No se encontraron certificados en TLS_CERT_PATH".into());
    }

    let key: PrivateKeyDer<'static> = {
        let mut r = BufReader::new(File::open(key_path)?);
        rustls_pemfile::private_key(&mut r)?
            .ok_or("No se encontró clave privada en TLS_KEY_PATH")?
    };

    let server_cfg = ServerConfig::builder()
        .with_no_client_auth()
        .with_single_cert(certs, key)?;

    Ok(TlsAcceptor::from(Arc::new(server_cfg)))
}

// ── Ciclo de vida de una conexión

/// Gestiona el ciclo completo de una conexión WebSocket.
///
/// # Parámetros
/// - `ws_stream`: Flujo WebSocket ya aceptado.
/// - `peer_addr`: Dirección remota (para logs).
/// - `state`: Estado compartido del servidor.
///
/// # Fases
/// 1. **Esperar `Join`**: El cliente debe enviar un mensaje con `command: "join"` y `user_id`.
///    Si no lo hace en los primeros mensajes, se cierra la conexión.
/// 2. **Registrar**: Se añade el canal de salida a `UserMap`, se asigna sala por defecto (`general`).
/// 3. **Entregar pendientes**: Se recuperan mensajes no entregados y eventos almacenados en BD.
/// 4. **Bucle principal**:
///    - Procesa mensajes entrantes (texto) mediante `handle_message`.
///    - Envía ACK al cliente.
///    - Reenvía mensajes recibidos desde el canal mpsc (por ejemplo, desde otra instancia).
///    - Envía heartbeats periódicos y detecta timeout.
/// 5. **Limpieza**: Al salir, se eliminan las referencias a este canal de los mapas.
async fn handle_ws_stream<S>(
    ws_stream: WebSocketStream<S>,
    peer_addr: SocketAddr,
    state: ServerState,
) where
    S: tokio::io::AsyncRead + tokio::io::AsyncWrite + Unpin,
{
    let (mut ws_sink, mut ws_stream) = ws_stream.split();
    let (tx, mut rx) = mpsc::channel::<WsMessage>(CHANNEL_CAPACITY);

    // ── Fase 1: esperar Join
    let user_id = loop {
        match ws_stream.next().await {
            Some(Ok(WsMessage::Text(raw))) => {
                match serde_json::from_str::<crate::types::Message>(&raw) {
                    Ok(msg) if msg.command == crate::types::Command::Join => {
                        if let Some(uid) = msg.user_id {
                            break uid;
                        }
                        let _ = ws_sink
                            .send(WsMessage::Text(r#"{"error":"Join requires user_id"}"#.into()))
                            .await;
                    }
                    _ => {
                        let _ = ws_sink
                            .send(WsMessage::Text(r#"{"error":"Send Join first"}"#.into()))
                            .await;
                    }
                }
            }
            _ => {
                info!("Conexión cerrada antes del Join: {}", peer_addr);
                return;
            }
        }
    };

    info!("Usuario '{}' conectado desde {}", user_id, peer_addr);

    // Upsert en DB (ignora si el user_id no es UUID — sesiones de prueba).
    if let Err(e) = crate::db::queries::upsert_user(&state.pool, &user_id).await {
        error!("upsert_user '{}': {}", user_id, e);
    }

    // ── Fase 2: registrar en los mapas
    state.user_map.entry(user_id.clone()).or_default().push(tx);
    state.room_map.entry(user_id.clone()).or_insert_with(|| "general".to_string());
    state.room_user_map.entry("general".to_string()).or_default().insert(user_id.clone());

    // ── Fase 3: entregar pendientes
    deliver_pending(&user_id, &state.pool, &mut ws_sink).await;

    let _ = ws_sink
        .send(WsMessage::Text(
            format!(r#"{{"event":"connected","user_id":"{}"}}"#, user_id).into(),
        ))
        .await;

    // ── Fase 4: bucle principal
    let heartbeat_start = tokio::time::Instant::now() + HEARTBEAT_INTERVAL;
    let mut heartbeat = interval_at(heartbeat_start, HEARTBEAT_INTERVAL);
    let mut pending_pong = false;

    loop {
        tokio::select! {
            msg = ws_stream.next() => match msg {
                Some(Ok(WsMessage::Text(text))) => {
                    pending_pong = false;
                    handle_message(
                        &text, &user_id,
                        &state.user_map, &state.room_map, &state.room_user_map,
                        &state.cache_map, &state.rate_limit_map, &state.instance_id,
                        &state.pool,
                    ).await;
                    let _ = ws_sink.send(WsMessage::Text("ACK".into())).await;
                }
                Some(Ok(WsMessage::Pong(_))) => {
                    pending_pong = false;
                    debug!("Pong de '{}'", user_id);
                }
                Some(Ok(WsMessage::Close(frame))) => {
                    let reason = frame
                        .map(|f| format!("code={} reason=\"{}\"", f.code, f.reason))
                        .unwrap_or_else(|| "sin detalle".to_string());
                    info!("Cierre de '{}' ({})", user_id, reason);
                    break;
                }
                Some(Ok(WsMessage::Binary(_))) => {
                    debug!("Binario ignorado de '{}'", user_id);
                }
                Some(Err(e)) => {
                    error!("Error stream '{}': {}", user_id, e);
                    break;
                }
                None => break,
                _ => {}
            },
            Some(fwd) = rx.recv() => {
                if let Err(e) = ws_sink.send(fwd).await {
                    error!("Error reenvío a '{}': {}", user_id, e);
                    break;
                }
            }
            _ = heartbeat.tick() => {
                if pending_pong {
                    warn!("Timeout pong '{}', cerrando", user_id);
                    break;
                }
                if let Err(e) = ws_sink.send(WsMessage::Ping(Default::default())).await {
                    error!("Error ping '{}': {}", user_id, e);
                    break;
                }
                pending_pong = true;
            }
        }
    }

    // ── Fase 5: limpiar mapas
    let current_room = state.room_map.get(&user_id).map(|r| r.clone());
    let all_closed = state.user_map
        .get_mut(&user_id)
        .map(|mut senders| { senders.retain(|s| !s.is_closed()); senders.is_empty() })
        .unwrap_or(true);

    if all_closed {
        state.user_map.remove(&user_id);
        state.room_map.remove(&user_id);
        if let Some(room_id) = current_room {
            if let Some(mut members) = state.room_user_map.get_mut(&room_id) {
                members.remove(&user_id);
            }
        }
    }
    info!("Sesión finalizada: '{}' ({})", user_id, peer_addr);
}

// ── Entrega de pendientes

/// Entrega mensajes y eventos pendientes a un usuario que acaba de conectarse.
///
/// # Parámetros
/// - `user_id`: Identificador del usuario.
/// - `pool`: Pool de conexiones.
/// - `sink`: Sink WebSocket para enviar los mensajes.
///
/// # Comportamiento
/// 1. Recupera y elimina los mensajes no entregados (`drain_undelivered`).
/// 2. Recupera y elimina los eventos pendientes (`drain_pending_events`).
/// 3. Envía cada elemento al cliente como un mensaje WebSocket.
/// 4. Si ocurre un error en alguna consulta, se registra y continúa.
async fn deliver_pending(
    user_id: &str,
    pool: &PgPool,
    sink: &mut (impl SinkExt<WsMessage> + Unpin),
) {
    match crate::db::queries::drain_undelivered(pool, user_id).await {
        Ok(msgs) => {
            for m in msgs {
                let payload = serde_json::json!({
                    "event": "offline_msg",
                    "room_id": m.room_id,
                    "sender_id": m.sender_id,
                    "content": m.content,
                    "sent_at": m.sent_at.to_string(),
                });
                let _ = sink.send(WsMessage::Text(payload.to_string().into())).await;
            }
        }
        Err(e) => error!("drain_undelivered '{}': {}", user_id, e),
    }

    match crate::db::queries::drain_pending_events(pool, user_id).await {
        Ok(events) => {
            for ev in events {
                let payload = serde_json::json!({
                    "event": ev.event_type,
                    "payload": ev.payload,
                    "created_at": ev.created_at.to_string(),
                });
                let _ = sink.send(WsMessage::Text(payload.to_string().into())).await;
            }
        }
        Err(e) => error!("drain_pending_events '{}': {}", user_id, e),
    }
}

// ── PG LISTEN / NOTIFY

/// Tarea permanente que escucha el canal `ws_broadcast` de PostgreSQL.
///
/// # Parámetros
/// - `database_url`: URL de conexión a la base de datos.
/// - `instance_id`: Identificador único de esta instancia del servidor.
/// - `user_map`: Mapa de usuarios a canales (para entregar mensajes localmente).
/// - `room_user_map`: Mapa de salas a usuarios (para broadcast local).
///
/// # Comportamiento
/// - Se conecta a PostgreSQL y ejecuta `LISTEN ws_broadcast`.
/// - Por cada notificación recibida, llama a `handle_pg_notification` si el mensaje
///   no es originario de esta instancia.
/// - En caso de error de conexión, espera 2 segundos y reconecta (backoff simple).
async fn start_pg_listener(
    database_url: String,
    instance_id: Arc<String>,
    user_map: UserMap,
    room_user_map: RoomUserMap,
) {
    loop {
        match PgListener::connect(&database_url).await {
            Ok(mut listener) => {
                if let Err(e) = listener.listen("ws_broadcast").await {
                    error!("PgListener listen: {}", e);
                    tokio::time::sleep(Duration::from_secs(2)).await;
                    continue;
                }
                info!("PgListener conectado al canal 'ws_broadcast'");
                loop {
                    match listener.recv().await {
                        Ok(n) => handle_pg_notification(n.payload(), &instance_id, &user_map, &room_user_map).await,
                        Err(e) => {
                            error!("PgListener recv: {}, reconectando…", e);
                            break;
                        }
                    }
                }
            }
            Err(e) => error!("PgListener connect: {}", e),
        }
        tokio::time::sleep(Duration::from_secs(2)).await;
    }
}

/// Reenvía localmente un mensaje recibido de otra instancia.
///
/// # Parámetros
/// - `payload`: Cuerpo JSON de la notificación.
/// - `my_instance`: Identificador de esta instancia.
/// - `user_map`: Mapa de usuarios a canales.
/// - `room_user_map`: Mapa de salas a usuarios.
///
/// # Comportamiento
/// - Si el campo `origin` coincide con `my_instance`, se ignora (ya fue entregado localmente).
/// - Extrae `room_id`, `sender`, `content`.
/// - Envía el mensaje a todos los usuarios conectados en esa sala (vía `user_map`).
async fn handle_pg_notification(
    payload: &str,
    my_instance: &str,
    user_map: &UserMap,
    room_user_map: &RoomUserMap,
) {
    let Ok(data) = serde_json::from_str::<serde_json::Value>(payload) else { return };

    if data["origin"].as_str() == Some(my_instance) {
        return; // ya entregado localmente
    }

    let Some(room_id) = data["room_id"].as_str() else { return };
    let sender  = data["sender"].as_str().unwrap_or("?");
    let content = data["content"].as_str().unwrap_or("");

    let ws_msg = WsMessage::Text(serde_json::json!({
        "event": "msg",
        "room_id": room_id,
        "sender": sender,
        "content": content,
    }).to_string().into());

    let Some(members) = room_user_map.get(room_id) else { return };
    let member_ids: Vec<String> = members.value().iter().cloned().collect();
    drop(members);

    for uid in &member_ids {
        if let Some(senders) = user_map.get(uid.as_str()) {
            for s in senders.iter() {
                let _ = s.try_send(ws_msg.clone());
            }
        }
    }
}