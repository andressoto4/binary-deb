//! Manejador de mensajes WebSocket para ws-unp.
//!
//! Este módulo contiene la lógica central de enrutamiento y procesamiento de
//! mensajes recibidos desde los clientes. Los mensajes se reciben como JSON,
//! se parsean a la estructura `Message` (definida en `types`), y se distribuyen
//! a funciones específicas según el comando.
//!
//! # Flujo de procesamiento
//! 1. Se recibe un mensaje JSON de un cliente.
//! 2. Se parsea; si falla, se descarta y se registra un error.
//! 3. Se identifica el comando (`Command`).
//! 4. Se llama al handler correspondiente.
//! 5. Los handlers realizan la lógica de negocio y, cuando es necesario, actualizan
//!    las estructuras en memoria (`UserMap`, `RoomMap`, `RoomUserMap`, etc.)
//!    y/o persisten en la base de datos.
//!
//! # Estructuras en memoria (definidas en `websocket/server.rs`)
//! - `UserMap`: `DashMap<String, Vec<tokio::sync::mpsc::UnboundedSender<WsMessage>>>`
//!    Almacena los canales de salida para cada usuario conectado.
//! - `RoomMap`: `DashMap<String, String>` – asigna cada usuario a la sala en la que se encuentra.
//! - `RoomUserMap`: `DashMap<String, DashSet<String>>` – lista de usuarios en cada sala.
//! - `CacheMap`: `DashMap<String, String>` – caché de nombres de sala (room_id -> nombre).
//! - `RateLimitMap`: `DashMap<String, (u32, Instant)>` – control de frecuencia de mensajes.
//!
//! # Seguridad
//! - Todos los mensajes se validan antes de ser procesados.
//! - Se aplica rate limiting para evitar abusos.
//! - Los UUIDs se parsean solo cuando es necesario, evitando consultas innecesarias.
//! - Las operaciones de base de datos se realizan en tareas asíncronas separadas,
//!   sin bloquear el envío del ACK al cliente.

use std::time::{Duration, Instant};

use sqlx::PgPool;
use tokio_tungstenite::tungstenite::protocol::Message as WsMessage;
use tracing::{debug, error, info, warn};
use uuid::Uuid;

use crate::db::queries::{
    create_room, get_room_name, insert_message, insert_pending_event, insert_undelivered,
    join_room, offline_room_members, pg_notify,
};
use crate::types::{Command, Message};
use crate::websocket::server::{
    CacheMap, RateLimitMap, RoomMap, RoomUserMap, UserMap, RATE_LIMIT_MAX, RATE_LIMIT_WINDOW_SECS,
};

// ── Helpers internos

/// Intenta entregar `msg` a todas las conexiones activas del usuario.
///
/// # Parámetros
/// - `user_id`: Identificador del usuario destino.
/// - `msg`: Mensaje WebSocket a enviar.
/// - `user_map`: Mapa global de usuarios a canales.
///
/// # Retorno
/// `true` si al menos un canal estaba abierto y se intentó la entrega,
/// `false` si el usuario no tiene canales registrados.
///
/// # Comportamiento
/// - Itera sobre todos los canales del usuario (puede haber múltiples conexiones).
/// - Si un canal está cerrado, se ignora (no se elimina aquí; la limpieza ocurre en broadcast).
/// - Si el canal está lleno (`TrySendError::Full`), se registra una advertencia.
fn deliver_to_user(user_id: &str, msg: WsMessage, user_map: &UserMap) -> bool {
    let Some(senders) = user_map.get(user_id) else { return false };
    let mut delivered = false;
    for s in senders.iter().filter(|s| !s.is_closed()) {
        let _ = s.try_send(msg.clone());
        delivered = true;
    }
    delivered
}

/// Mueve a `user_id` de su sala actual a `new_room` en los mapas en memoria.
///
/// # Parámetros
/// - `user_id`: Identificador del usuario.
/// - `new_room`: Nueva sala (identificador).
/// - `room_map`: Mapa que asigna usuario a sala actual.
/// - `room_user_map`: Mapa que asigna sala a conjunto de usuarios.
///
/// # Comportamiento
/// - Si el usuario ya está en `new_room`, no hace nada.
/// - Si el usuario estaba en otra sala, lo remueve de esa lista y luego lo añade a `new_room`.
fn switch_room(
    user_id: &str,
    new_room: &str,
    room_map: &RoomMap,
    room_user_map: &RoomUserMap,
) {
    if let Some(old_room) = room_map.get(user_id).map(|r| r.clone()) {
        if old_room == new_room { return; }
        if let Some(mut members) = room_user_map.get_mut(&old_room) {
            members.remove(user_id);
        }
    }
    room_map.insert(user_id.to_string(), new_room.to_string());
    room_user_map.entry(new_room.to_string()).or_default().insert(user_id.to_string());
}

/// Verifica el rate limit del usuario.
///
/// # Parámetros
/// - `user_id`: Identificador del usuario.
/// - `rate_limit_map`: Mapa de control de frecuencia.
///
/// # Retorno
/// `true` si el mensaje debe ser descartado (por exceder el límite),
/// `false` si puede procesarse.
///
/// # Comportamiento
/// - Utiliza una ventana deslizante de `RATE_LIMIT_WINDOW_SECS` segundos.
/// - Permite hasta `RATE_LIMIT_MAX` mensajes por ventana.
/// - Si el usuario supera el límite, se registra una advertencia y se rechaza el mensaje.
fn rate_limited(user_id: &str, rate_limit_map: &RateLimitMap) -> bool {
    let now = Instant::now();
    let window = Duration::from_secs(RATE_LIMIT_WINDOW_SECS);
    let mut entry = rate_limit_map
        .entry(user_id.to_string())
        .or_insert((0, now));
    if now.duration_since(entry.1) >= window {
        *entry = (1, now);
        false
    } else {
        entry.0 += 1;
        if entry.0 > RATE_LIMIT_MAX {
            warn!("Rate limit excedido para '{}', mensaje descartado", user_id);
            true
        } else {
            false
        }
    }
}

// ── Enrutador central

/// Decodifica y enruta un mensaje JSON recibido del cliente.
///
/// Es el punto de entrada principal para todos los mensajes entrantes.
///
/// # Parámetros
/// - `raw`: Cadena JSON recibida del WebSocket.
/// - `sender_id`: Identificador del usuario que envía el mensaje.
/// - `user_map`: Mapa de usuarios a canales.
/// - `room_map`: Mapa de usuario -> sala actual.
/// - `room_user_map`: Mapa de sala -> conjunto de usuarios.
/// - `cache_map`: Caché de nombres de sala.
/// - `rate_limit_map`: Mapa de rate limiting.
/// - `instance_id`: Identificador único de esta instancia del servidor.
/// - `pool`: Pool de conexiones a PostgreSQL.
///
/// # Comportamiento
/// 1. Intenta parsear el JSON a `Message`.
/// 2. Si falla, registra error y retorna.
/// 3. Según el comando, llama al handler correspondiente.
/// 4. Los comandos `Join` y `Leave` no tienen lógica en este punto (se manejan en la conexión).
pub async fn handle_message(
    raw: &str,
    sender_id: &str,
    user_map: &UserMap,
    room_map: &RoomMap,
    room_user_map: &RoomUserMap,
    cache_map: &CacheMap,
    rate_limit_map: &RateLimitMap,
    instance_id: &str,
    pool: &PgPool,
) {
    let msg: Message = match serde_json::from_str(raw) {
        Ok(m) => m,
        Err(e) => { error!("JSON inválido de '{}': {}", sender_id, e); return; }
    };

    match msg.command {
        Command::Msg => handle_msg(msg, sender_id, user_map, room_user_map, rate_limit_map, instance_id, pool).await,
        Command::Notify => handle_notify(msg, sender_id, user_map, pool).await,
        Command::MailUpdate => handle_mail_update(msg, sender_id, user_map, pool).await,
        Command::CreateRoom => handle_create_room(msg, sender_id, user_map, room_map, room_user_map, cache_map, pool).await,
        Command::JoinRoom => handle_join_room(msg, sender_id, user_map, room_map, room_user_map, cache_map, pool).await,
        Command::Join | Command::Leave => {}
    }
}

// ── Handlers por comando

/// Procesa un mensaje de chat (`Command::Msg`).
///
/// # Parámetros
/// - `msg`: Mensaje parseado.
/// - `sender_id`: Emisor.
/// - `user_map`: Mapa de usuarios a canales.
/// - `room_user_map`: Mapa de sala -> usuarios.
/// - `rate_limit_map`: Mapa de rate limiting.
/// - `instance_id`: Identificador de la instancia.
/// - `pool`: Pool de conexiones.
///
/// # Comportamiento
/// 1. Extrae `room_id` y `content` del mensaje.
/// 2. Aplica rate limiting; si se excede, descarta.
/// 3. Realiza broadcast local a todos los miembros de la sala (excepto el emisor).
///    - Durante el broadcast, detecta y elimina canales muertos (zombies).
/// 4. Lanza una tarea asíncrona para:
///    - Notificar a otras instancias mediante `pg_notify`.
///    - Persistir el mensaje en la base de datos.
///    - Identificar usuarios offline y encolar mensajes no entregados.
///
/// # Seguridad
/// - El rate limiting previene ataques de flooding.
/// - La persistencia y notificación ocurren fuera del camino crítico para no bloquear la respuesta.
async fn handle_msg(
    msg: Message,
    sender_id: &str,
    user_map: &UserMap,
    room_user_map: &RoomUserMap,
    rate_limit_map: &RateLimitMap,
    instance_id: &str,
    pool: &PgPool,
) {
    let Some(room_id) = msg.room_id else {
        warn!("Msg sin room_id de '{}'", sender_id);
        return;
    };
    let content = msg.content.as_deref().unwrap_or("");

    if rate_limited(sender_id, rate_limit_map) { return; }

    info!("Msg sala='{}' de='{}': {}", room_id, sender_id, content);

    // 1. Broadcast local O(miembros de sala).
    let ws_payload = WsMessage::Text(serde_json::json!({
        "event": "msg",
        "room_id": room_id,
        "sender": sender_id,
        "content": content,
    }).to_string().into());

    if let Some(members) = room_user_map.get(&room_id) {
        let member_ids: Vec<String> = members.value().iter().cloned().collect();
        drop(members);
        let mut stale: Vec<String> = Vec::new();
        for uid in &member_ids {
            if uid == sender_id { continue; }
            if let Some(senders) = user_map.get(uid.as_str()) {
                if senders.iter().all(|s| s.is_closed()) {
                    stale.push(uid.clone());
                    continue;
                }
                for s in senders.iter() {
                    match s.try_send(ws_payload.clone()) {
                        Ok(_) => {}
                        Err(tokio::sync::mpsc::error::TrySendError::Full(_)) =>
                            warn!("Canal lleno para '{}' (cliente lento)", uid),
                        Err(tokio::sync::mpsc::error::TrySendError::Closed(_)) => {}
                    }
                }
            }
        }
        // Limpiar zombies detectados durante el broadcast.
        for uid in stale {
            user_map.remove(&uid);
            if let Some(mut m) = room_user_map.get_mut(&room_id) { m.remove(&uid); }
            debug!("Zombie eliminado: '{}'", uid);
        }
    }

    // 2 y 3. pg_notify + persistencia en BD — fuera del camino crítico.
    // El broadcast en memoria ya ocurrió; la tarea secundaria no bloquea el ACK al cliente.
    // Se captura el snapshot de usuarios online en este instante para identificar destinatarios offline.
    let online         = user_map.iter().map(|e| e.key().clone()).collect::<Vec<_>>();
    let pool_bg        = pool.clone();
    let room_id_bg     = room_id.clone();
    let sender_id_bg   = sender_id.to_string();
    let content_bg     = content.to_string();
    let instance_id_bg = instance_id.to_string();
    tokio::spawn(async move {
        // Notificar a otras instancias vía PG LISTEN/NOTIFY.
        let notify_payload = serde_json::json!({
            "event": "msg", "room_id": room_id_bg,
            "sender": sender_id_bg, "content": content_bg, "origin": instance_id_bg,
        }).to_string();
        if let Err(e) = pg_notify(&pool_bg, &notify_payload).await {
            error!("pg_notify: {}", e);
        }

        // Persistir en BD (solo si ambos IDs son UUIDs).
        let room_uuid   = Uuid::parse_str(&room_id_bg).ok();
        let sender_uuid = Uuid::parse_str(&sender_id_bg).ok();
        if let (Some(_), Some(_)) = (room_uuid, sender_uuid) {
            match insert_message(&pool_bg, &room_id_bg, &sender_id_bg, &content_bg).await {
                Ok(message_id) => {
                    match offline_room_members(&pool_bg, &room_id_bg, &online).await {
                        Ok(offline) if !offline.is_empty() => {
                            if let Err(e) = insert_undelivered(&pool_bg, message_id, &offline).await {
                                error!("insert_undelivered: {}", e);
                            }
                        }
                        Err(e) => error!("offline_room_members: {}", e),
                        _ => {}
                    }
                }
                Err(e) => error!("insert_message: {}", e),
            }
        }
    });
}

/// Procesa una notificación (`Command::Notify`).
///
/// # Parámetros
/// - `msg`: Mensaje parseado.
/// - `sender_id`: Emisor.
/// - `user_map`: Mapa de usuarios a canales.
/// - `pool`: Pool de conexiones.
///
/// # Comportamiento
/// 1. Extrae `user_id` (destinatario) y `content`.
/// 2. Si el destinatario está conectado, envía la notificación directamente.
/// 3. Si no está conectado y el ID es un UUID válido, encola el evento en la base de datos.
async fn handle_notify(msg: Message, sender_id: &str, user_map: &UserMap, pool: &PgPool) {
    let Some(target) = msg.user_id else {
        warn!("Notify sin user_id de '{}'", sender_id);
        return;
    };
    let content = msg.content.as_deref().unwrap_or("");
    info!("Notify → '{}': {}", target, content);

    let payload = serde_json::json!({"event": "notify", "from": sender_id, "content": content});
    if !deliver_to_user(&target, WsMessage::Text(payload.to_string().into()), user_map)
        && Uuid::parse_str(&target).is_ok()
    {
        // Usuario offline: encolar evento en BD fuera del camino crítico.
        let pool_bg    = pool.clone();
        let target_bg  = target.clone();
        let payload_bg = payload.clone();
        tokio::spawn(async move {
            if let Err(e) = insert_pending_event(&pool_bg, &target_bg, "notify", &payload_bg).await {
                error!("insert_pending_event notify: {}", e);
            }
        });
    }
}

/// Procesa una alerta de actualización de correo (`Command::MailUpdate`).
///
/// Similar a `handle_notify`, pero con tipo de evento específico.
///
/// # Parámetros
/// - `msg`: Mensaje parseado.
/// - `sender_id`: Emisor.
/// - `user_map`: Mapa de usuarios a canales.
/// - `pool`: Pool de conexiones.
///
/// # Comportamiento
/// 1. Extrae `user_id` (destinatario) y `content`.
/// 2. Si el destinatario está conectado, envía la alerta.
/// 3. Si no está conectado y el ID es un UUID válido, encola el evento en la base de datos.
async fn handle_mail_update(msg: Message, sender_id: &str, user_map: &UserMap, pool: &PgPool) {
    let Some(target) = msg.user_id else {
        warn!("MailUpdate sin user_id de '{}'", sender_id);
        return;
    };
    let content = msg.content.as_deref().unwrap_or("");
    info!("MailUpdate → '{}': {}", target, content);

    let payload = serde_json::json!({"event": "mail_update", "content": content});
    if !deliver_to_user(&target, WsMessage::Text(payload.to_string().into()), user_map)
        && Uuid::parse_str(&target).is_ok()
    {
        // Usuario offline: encolar evento en BD fuera del camino crítico.
        let pool_bg    = pool.clone();
        let target_bg  = target.clone();
        let payload_bg = payload.clone();
        tokio::spawn(async move {
            if let Err(e) = insert_pending_event(&pool_bg, &target_bg, "mail_update", &payload_bg).await {
                error!("insert_pending_event mail_update: {}", e);
            }
        });
    }
}

/// Crea una nueva sala (`Command::CreateRoom`).
///
/// # Parámetros
/// - `msg`: Mensaje parseado.
/// - `sender_id`: Usuario que crea la sala.
/// - `user_map`: Mapa de usuarios a canales.
/// - `room_map`: Mapa de usuario -> sala actual.
/// - `room_user_map`: Mapa de sala -> usuarios.
/// - `cache_map`: Caché de nombres de sala.
/// - `pool`: Pool de conexiones.
///
/// # Comportamiento
/// 1. Extrae el nombre de la sala desde `content`.
/// 2. Crea la sala en la base de datos y obtiene su UUID.
/// 3. Añade el creador como miembro de la sala.
/// 4. Actualiza los mapas en memoria para reflejar que el usuario ahora está en esa sala.
/// 5. Envía al cliente un mensaje con el UUID de la sala creada.
async fn handle_create_room(
    msg: Message,
    sender_id: &str,
    user_map: &UserMap,
    room_map: &RoomMap,
    room_user_map: &RoomUserMap,
    cache_map: &CacheMap,
    pool: &PgPool,
) {
    let Some(name) = msg.content.as_deref().map(str::trim).filter(|n| !n.is_empty()) else {
        warn!("CreateRoom sin nombre de '{}'", sender_id);
        return;
    };
    info!("CreateRoom '{}' por '{}'", name, sender_id);

    let room_id = match create_room(pool, name).await {
        Ok(id) => id,
        Err(e) => { error!("create_room: {}", e); return; }
    };

    info!("Sala '{}' creada: {}", name, room_id);
    cache_map.insert(room_id.to_string(), name.to_string());

    if let Ok(uid) = Uuid::parse_str(sender_id) {
        if let Err(e) = join_room(pool, room_id, uid).await {
            error!("join_room tras CreateRoom: {}", e);
        }
    }

    switch_room(sender_id, &room_id.to_string(), room_map, room_user_map);

    let resp = serde_json::json!({"event": "room_created", "room_id": room_id, "name": name});
    deliver_to_user(sender_id, WsMessage::Text(resp.to_string().into()), user_map);
}

/// Un usuario se une a una sala existente (`Command::JoinRoom`).
///
/// # Parámetros
/// - `msg`: Mensaje parseado.
/// - `sender_id`: Usuario que se une.
/// - `user_map`: Mapa de usuarios a canales.
/// - `room_map`: Mapa de usuario -> sala actual.
/// - `room_user_map`: Mapa de sala -> usuarios.
/// - `cache_map`: Caché de nombres de sala.
/// - `pool`: Pool de conexiones.
///
/// # Comportamiento
/// 1. Extrae `room_id` del mensaje.
/// 2. Añade al usuario como miembro de la sala en la base de datos (si no lo es ya).
/// 3. Obtiene el nombre de la sala (desde caché o base de datos).
/// 4. Actualiza los mapas en memoria para reflejar el cambio de sala.
/// 5. Envía al cliente un mensaje de confirmación con el nombre de la sala.
async fn handle_join_room(
    msg: Message,
    sender_id: &str,
    user_map: &UserMap,
    room_map: &RoomMap,
    room_user_map: &RoomUserMap,
    cache_map: &CacheMap,
    pool: &PgPool,
) {
    let Some(room_id_str) = msg.room_id else {
        warn!("JoinRoom sin room_id de '{}'", sender_id);
        return;
    };
    info!("JoinRoom '{}' por '{}'", room_id_str, sender_id);

    let room_name = if let Ok(room_uuid) = Uuid::parse_str(&room_id_str) {
        if let Ok(sender_uuid) = Uuid::parse_str(sender_id) {
            if let Err(e) = join_room(pool, room_uuid, sender_uuid).await {
                error!("join_room: {}", e);
            }
        }
        if let Some(cached) = cache_map.get(&room_id_str) {
            cached.clone()
        } else {
            let name = match get_room_name(pool, &room_id_str).await {
                Ok(Some(n)) => n,
                Ok(None)    => room_id_str.clone(),
                Err(e)      => { error!("get_room_name: {}", e); room_id_str.clone() }
            };
            cache_map.insert(room_id_str.clone(), name.clone());
            name
        }
    } else {
        room_id_str.clone()
    };

    switch_room(sender_id, &room_id_str, room_map, room_user_map);

    let resp = serde_json::json!({"event": "room_joined", "room_id": room_id_str, "name": room_name});
    deliver_to_user(sender_id, WsMessage::Text(resp.to_string().into()), user_map);
}