//! Módulo WebSocket para ws-unp.
//!
//! Este módulo contiene la implementación del servidor WebSocket y los manejadores
//! de mensajes. Se divide en dos submódulos:
//! - `server`: Configuración del servidor, gestión de conexiones y estructuras en memoria.
//! - `handlers`: Lógica de enrutamiento y procesamiento de mensajes entrantes.
//!
//! # Flujo de funcionamiento
//! 1. El submódulo `server` inicia un listener WebSocket y acepta conexiones.
//! 2. Por cada conexión, se autentica al cliente (mediante el mensaje `Join`) y se registra
//!    en las estructuras en memoria (`UserMap`, `RoomMap`, etc.).
//! 3. Los mensajes entrantes se pasan al submódulo `handlers` a través de `handle_message`.
//! 4. Los handlers procesan los comandos, actualizan el estado en memoria y persisten
//!    en la base de datos según corresponda.
//!
//! # Seguridad
//! - Se utiliza rate limiting para evitar flooding.
//! - Las conexiones se autentican mediante un mensaje `Join` antes de permitir acciones.
//! - Los mensajes malformados se descartan con registro de error.

pub mod server;
pub mod handlers;